-- infra/docker/postgres/init.sql
-- Production PostgreSQL 16 schema for PredMarket.
-- Applied automatically on first container startup.
--
-- Design principles:
--   1. Hash partitioning by market_id on orders and fills.
--      Keeps hot data for a single market on a small set of pages.
--   2. Indexes cover the access patterns from the Rust query layer.
--   3. user_balances uses advisory locking at the app layer (Rust),
--      not row-level locking, to keep balance updates fast.

-- ── Extensions ─────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";   -- query analytics

-- ── Users ──────────────────────────────────────────────────────────────────
CREATE TABLE users (
    user_id      UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    email        TEXT        NOT NULL UNIQUE,
    -- Password hash stored as argon2 string (e.g. "$argon2id$v=19$...")
    password_hash TEXT       NOT NULL,
    roles        INTEGER     NOT NULL DEFAULT 0,   -- bitmask: 0x01=admin
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── User Balances ───────────────────────────────────────────────────────────
-- Single row per user. Rust uses optimistic locking (SELECT ... FOR UPDATE)
-- or Redis Lua scripts for reservation; PG is authoritative.
CREATE TABLE user_balances (
    user_id      UUID        PRIMARY KEY REFERENCES users(user_id),
    available    BIGINT      NOT NULL DEFAULT 0 CHECK (available >= 0),
    reserved     BIGINT      NOT NULL DEFAULT 0 CHECK (reserved >= 0),
    -- Soft-check: available + reserved = total (enforced by app, not DB)
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Markets ─────────────────────────────────────────────────────────────────
CREATE TABLE markets (
    market_id    UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    title        TEXT        NOT NULL,
    description  TEXT        NOT NULL DEFAULT '',
    -- 0=open 1=paused 2=settled 3=cancelled
    status       SMALLINT    NOT NULL DEFAULT 0,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolves_at  TIMESTAMPTZ,
    settled_at   TIMESTAMPTZ,
    -- 0=yes_wins 1=no_wins NULL=not settled
    resolution   SMALLINT
);

CREATE INDEX idx_markets_status ON markets(status);
CREATE INDEX idx_markets_resolves_at ON markets(resolves_at) WHERE resolves_at IS NOT NULL;

-- ── Orders (hash partitioned by market_id, 8 partitions) ────────────────────
-- 8 partitions is appropriate for up to ~1,000 markets.
-- Each partition is ~1/8 of total order volume; index scans stay tight.
CREATE TABLE orders (
    order_id        UUID        NOT NULL,
    market_id       UUID        NOT NULL REFERENCES markets(market_id),
    user_id         UUID        NOT NULL REFERENCES users(user_id),
    side            SMALLINT    NOT NULL,          -- 0=buy 1=sell
    order_type      SMALLINT    NOT NULL,          -- 0=limit 1=market
    -- Fixed-point price × 10000. NULL for market orders.
    price           INTEGER     CHECK (price IS NULL OR (price > 0 AND price < 10000)),
    quantity        BIGINT      NOT NULL CHECK (quantity > 0),
    filled_quantity BIGINT      NOT NULL DEFAULT 0,
    -- 0=open 1=partial 2=filled 3=cancelled 4=rejected
    status          SMALLINT    NOT NULL DEFAULT 0,
    sequence_number BIGINT      NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (order_id, market_id)
) PARTITION BY HASH (market_id);

-- Create 8 hash partitions
DO $$
BEGIN
    FOR i IN 0..7 LOOP
        EXECUTE format(
            'CREATE TABLE orders_p%s PARTITION OF orders
             FOR VALUES WITH (MODULUS 8, REMAINDER %s)',
            i, i
        );
    END LOOP;
END $$;

-- Indexes on each partition are inherited automatically
CREATE INDEX idx_orders_market_status
    ON orders(market_id, status, side, price)
    WHERE status IN (0, 1);  -- partial index: only open/partial orders

CREATE INDEX idx_orders_user
    ON orders(user_id, created_at DESC);

CREATE INDEX idx_orders_sequence
    ON orders(market_id, sequence_number);

-- ── Fills ────────────────────────────────────────────────────────────────────
CREATE TABLE fills (
    fill_id         UUID        NOT NULL,
    market_id       UUID        NOT NULL REFERENCES markets(market_id),
    maker_order_id  UUID        NOT NULL,
    taker_order_id  UUID        NOT NULL,
    maker_user_id   UUID        NOT NULL REFERENCES users(user_id),
    taker_user_id   UUID        NOT NULL REFERENCES users(user_id),
    price           INTEGER     NOT NULL CHECK (price > 0 AND price < 10000),
    quantity        BIGINT      NOT NULL CHECK (quantity > 0),
    aggressor_side  SMALLINT    NOT NULL,   -- 0=buy 1=sell
    fill_seq        BIGINT      NOT NULL,   -- engine-assigned monotonic
    filled_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (fill_id, market_id)
) PARTITION BY HASH (market_id);

DO $$
BEGIN
    FOR i IN 0..7 LOOP
        EXECUTE format(
            'CREATE TABLE fills_p%s PARTITION OF fills
             FOR VALUES WITH (MODULUS 8, REMAINDER %s)',
            i, i
        );
    END LOOP;
END $$;

CREATE INDEX idx_fills_market_time
    ON fills(market_id, filled_at DESC);

CREATE INDEX idx_fills_user_maker
    ON fills(maker_user_id, filled_at DESC);

CREATE INDEX idx_fills_user_taker
    ON fills(taker_user_id, filled_at DESC);

-- ── Positions ────────────────────────────────────────────────────────────────
-- Net position per user per market after all fills.
-- Maintained by the Rust event processor, not by triggers (triggers add latency).
CREATE TABLE positions (
    user_id      UUID        NOT NULL REFERENCES users(user_id),
    market_id    UUID        NOT NULL REFERENCES markets(market_id),
    quantity     BIGINT      NOT NULL DEFAULT 0,   -- net (positive=long, negative=short)
    avg_price    INTEGER     NOT NULL DEFAULT 0,   -- fixed-point
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, market_id)
);

CREATE INDEX idx_positions_market ON positions(market_id);

-- ── Settlement Payouts ───────────────────────────────────────────────────────
CREATE TABLE settlement_payouts (
    payout_id    UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    market_id    UUID        NOT NULL REFERENCES markets(market_id),
    user_id      UUID        NOT NULL REFERENCES users(user_id),
    amount       BIGINT      NOT NULL,   -- base units × 10^6
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_payouts_market ON settlement_payouts(market_id);
CREATE INDEX idx_payouts_user   ON settlement_payouts(user_id);

-- ── Audit Log ───────────────────────────────────────────────────────────────
-- Append-only log of significant events for compliance and debugging.
-- Written by Rust services; never updated.
CREATE TABLE audit_log (
    log_id       BIGSERIAL   PRIMARY KEY,
    event_type   TEXT        NOT NULL,   -- 'ORDER_SUBMITTED', 'FILL', 'MARKET_SETTLED', etc.
    user_id      UUID,
    market_id    UUID,
    payload      JSONB       NOT NULL DEFAULT '{}',
    occurred_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Partial index: only recent events queried by market or user
CREATE INDEX idx_audit_market_recent
    ON audit_log(market_id, occurred_at DESC)
    WHERE market_id IS NOT NULL;

CREATE INDEX idx_audit_user_recent
    ON audit_log(user_id, occurred_at DESC)
    WHERE user_id IS NOT NULL;

-- ── Seed data ───────────────────────────────────────────────────────────────
-- Dev-only admin user. Password: "dev-password" (argon2id hash placeholder).
-- IMPORTANT: Replace with real hashed credentials before any real deployment.
INSERT INTO users (user_id, email, password_hash, roles)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'admin@predmarket.dev',
    '$argon2id$v=19$m=65536,t=3,p=4$PLACEHOLDER_HASH_REPLACE_IN_PRODUCTION',
    1  -- admin role
);

INSERT INTO user_balances (user_id, available, reserved)
VALUES ('00000000-0000-0000-0000-000000000001', 1000000000, 0);

INSERT INTO markets (market_id, title, description, status)
VALUES (
    '10000000-0000-0000-0000-000000000001',
    'Will BTC exceed $100k by end of 2025?',
    'Resolves YES if BTC/USD closes above $100,000 on any tier-1 exchange.',
    0  -- open
);

-- Notify completion
DO $$ BEGIN
    RAISE NOTICE 'PredMarket schema initialized. Version: 1.0.0';
END $$;
