#pragma once
// engine/include/metrics.hpp
//
// Minimal metrics collector for the matching engine.
// Exposes a /metrics endpoint in Prometheus text format.
// Read-only. No external dependency — uses only POSIX sockets.
//
// Metrics exposed:
//   engine_orders_processed_total{market_id}
//   engine_fills_generated_total{market_id}
//   engine_cancels_processed_total{market_id}
//   engine_bid_book_size{market_id}
//   engine_ask_book_size{market_id}
//   engine_pool_available{market_id}
//   engine_loop_latency_ns (histogram: p50, p95, p99)
//   engine_wal_records_total{market_id}

#include <atomic>
#include <string>
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <sstream>

namespace predmarket {

// Lock-free HDR-style histogram with power-of-2 buckets
// Tracks nanosecond values from 100ns to 100ms
class LatencyHistogram {
public:
    static constexpr size_t BUCKET_COUNT = 64;

    void record(uint64_t ns) noexcept {
        // Map ns to bucket: bucket = min(63, floor(log2(ns)))
        size_t b = 0;
        if (ns > 0) {
            b = 63 - __builtin_clzll(ns);
            b = std::min(b, BUCKET_COUNT - 1);
        }
        buckets_[b].fetch_add(1, std::memory_order_relaxed);
        count_.fetch_add(1, std::memory_order_relaxed);
    }

    // Returns estimated percentile value in nanoseconds
    uint64_t percentile(double p) const noexcept {
        uint64_t total = count_.load(std::memory_order_relaxed);
        if (total == 0) return 0;

        uint64_t target = static_cast<uint64_t>(total * p / 100.0);
        uint64_t cumulative = 0;

        for (size_t i = 0; i < BUCKET_COUNT; ++i) {
            cumulative += buckets_[i].load(std::memory_order_relaxed);
            if (cumulative >= target) {
                return 1ULL << i;  // midpoint approximation
            }
        }
        return 1ULL << (BUCKET_COUNT - 1);
    }

    uint64_t count() const noexcept {
        return count_.load(std::memory_order_relaxed);
    }

private:
    std::array<std::atomic<uint64_t>, BUCKET_COUNT> buckets_{};
    std::atomic<uint64_t> count_{0};
};

struct EngineMetrics {
    std::atomic<uint64_t> orders_processed{0};
    std::atomic<uint64_t> fills_generated{0};
    std::atomic<uint64_t> cancels_processed{0};
    std::atomic<uint64_t> orders_rejected{0};
    std::atomic<uint64_t> wal_records{0};

    // Snapshot values — updated by engine loop, read by metrics thread
    std::atomic<uint64_t> bid_book_size{0};
    std::atomic<uint64_t> ask_book_size{0};
    std::atomic<uint64_t> pool_available{0};

    LatencyHistogram loop_latency_ns;

    std::string render_prometheus(const std::string& market_id) const {
        std::ostringstream out;
        auto lbl = "{market_id=\"" + market_id + "\"}";

        auto gauge = [&](const char* name, uint64_t val) {
            out << "# TYPE " << name << " gauge\n";
            out << name << lbl << " " << val << "\n";
        };
        auto counter = [&](const char* name, uint64_t val) {
            out << "# TYPE " << name << " counter\n";
            out << name << lbl << " " << val << "\n";
        };

        counter("engine_orders_processed_total",  orders_processed.load());
        counter("engine_fills_generated_total",   fills_generated.load());
        counter("engine_cancels_processed_total", cancels_processed.load());
        counter("engine_orders_rejected_total",   orders_rejected.load());
        counter("engine_wal_records_total",       wal_records.load());
        gauge  ("engine_bid_book_size",           bid_book_size.load());
        gauge  ("engine_ask_book_size",           ask_book_size.load());
        gauge  ("engine_pool_available",          pool_available.load());

        // Latency histogram summary
        out << "# TYPE engine_loop_latency_ns summary\n";
        out << "engine_loop_latency_ns{market_id=\"" << market_id << "\",quantile=\"0.50\"} "
            << loop_latency_ns.percentile(50.0) << "\n";
        out << "engine_loop_latency_ns{market_id=\"" << market_id << "\",quantile=\"0.95\"} "
            << loop_latency_ns.percentile(95.0) << "\n";
        out << "engine_loop_latency_ns{market_id=\"" << market_id << "\",quantile=\"0.99\"} "
            << loop_latency_ns.percentile(99.0) << "\n";
        out << "engine_loop_latency_ns_count" << lbl << " "
            << loop_latency_ns.count() << "\n";

        return out.str();
    }
};

} // namespace predmarket
