#pragma once
// engine/include/wal.hpp
//
// Write-Ahead Log (WAL) for the matching engine.
//
// DESIGN:
//   Binary append-only file. Every order event and fill is written here
//   BEFORE the NATS ACK is sent. On crash+restart, the engine replays
//   the WAL to rebuild order book state before resuming NATS consumption.
//
// FORMAT per record:
//   [4 bytes: magic 0xPMWL] [4 bytes: record type] [8 bytes: length]
//   [N bytes: payload] [4 bytes: CRC32 of payload]
//
// WRITE STRATEGY:
//   pwrite() to O_WRONLY|O_CREAT|O_APPEND fd.
//   fsync() called every 100 records or 10ms, whichever comes first.
//   The engine treats write failure as fatal (crash + restart is safer
//   than continuing with an incomplete journal).

#include "order_pool.hpp"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <chrono>

namespace predmarket {

constexpr uint32_t WAL_MAGIC      = 0x504D574C; // "PMWL"
constexpr uint32_t WAL_VERSION    = 1;
constexpr size_t   WAL_FSYNC_INTERVAL = 100;    // fsync every N records

enum class WalRecordType : uint32_t {
    Header    = 0,
    NewOrder  = 1,
    Cancel    = 2,
    Fill      = 3,
    Snapshot  = 4,   // periodic full book snapshot to bound replay time
    Checkpoint = 5,
};

#pragma pack(push, 1)
struct WalRecordHeader {
    uint32_t magic;        // WAL_MAGIC
    uint32_t type;         // WalRecordType
    uint64_t length;       // payload length in bytes
    uint64_t sequence;     // monotonic record sequence
    uint64_t timestamp_ns; // wall clock
};

struct WalNewOrderPayload {
    uint64_t sequence_number;
    uint64_t order_id_hi, order_id_lo;
    uint64_t user_id_hi, user_id_lo;
    uint64_t market_id_hi, market_id_lo;
    uint32_t price;
    uint64_t quantity;
    uint8_t  side;
    uint8_t  order_type;
};

struct WalCancelPayload {
    uint64_t sequence_number;
    uint64_t order_id_hi, order_id_lo;
};

struct WalFillPayload {
    uint64_t fill_id_hi, fill_id_lo;
    uint64_t maker_order_id_hi, maker_order_id_lo;
    uint64_t taker_order_id_hi, taker_order_id_lo;
    uint64_t maker_user_id_hi, maker_user_id_lo;
    uint64_t taker_user_id_hi, taker_user_id_lo;
    uint32_t price;
    uint64_t quantity;
    uint8_t  aggressor_side;
    uint64_t sequence;
    uint64_t timestamp_ns;
};
#pragma pack(pop)

// Simple CRC32 implementation (polynomial 0xEDB88320)
inline uint32_t crc32(const void* data, size_t len) noexcept {
    uint32_t crc = 0xFFFFFFFF;
    const auto* bytes = static_cast<const uint8_t*>(data);
    for (size_t i = 0; i < len; ++i) {
        crc ^= bytes[i];
        for (int j = 0; j < 8; ++j) {
            crc = (crc >> 1) ^ (0xEDB88320 & -(crc & 1));
        }
    }
    return crc ^ 0xFFFFFFFF;
}

class Wal {
public:
    explicit Wal(const std::string& path)
        : path_(path), record_count_(0), wal_seq_(0)
    {
        fd_ = open(path.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (fd_ < 0) {
            throw std::runtime_error("WAL: cannot open file: " + path);
        }

        // Write file header if new file
        struct stat st;
        fstat(fd_, &st);
        if (st.st_size == 0) {
            write_file_header();
        } else {
            // Existing file: read last sequence from trailer
            // (simplified: scan to find highest sequence — real impl would use index)
            recover_wal_sequence();
        }
    }

    ~Wal() {
        fsync(fd_);
        close(fd_);
    }

    void append_new_order(const WalNewOrderPayload& p) {
        write_record(WalRecordType::NewOrder, &p, sizeof(p));
    }

    void append_cancel(const WalCancelPayload& p) {
        write_record(WalRecordType::Cancel, &p, sizeof(p));
    }

    void append_fill(const WalFillPayload& p) {
        write_record(WalRecordType::Fill, &p, sizeof(p));
    }

    void force_sync() {
        if (fsync(fd_) != 0) {
            throw std::runtime_error("WAL: fsync failed — treating as fatal");
        }
    }

    uint64_t last_sequence() const noexcept { return wal_seq_; }

private:
    std::string path_;
    int         fd_;
    uint64_t    record_count_;
    uint64_t    wal_seq_;

    uint64_t now_ns() {
        using namespace std::chrono;
        return static_cast<uint64_t>(
            duration_cast<nanoseconds>(
                steady_clock::now().time_since_epoch()
            ).count()
        );
    }

    void write_file_header() {
        struct {
            uint32_t magic;
            uint32_t version;
            uint8_t  reserved[56];
        } hdr = { WAL_MAGIC, WAL_VERSION, {} };
        write_all(&hdr, sizeof(hdr));
    }

    void write_record(WalRecordType type, const void* payload, size_t len) {
        ++wal_seq_;

        WalRecordHeader hdr;
        hdr.magic        = WAL_MAGIC;
        hdr.type         = static_cast<uint32_t>(type);
        hdr.length       = len;
        hdr.sequence     = wal_seq_;
        hdr.timestamp_ns = now_ns();

        uint32_t checksum = crc32(payload, len);

        write_all(&hdr, sizeof(hdr));
        write_all(payload, len);
        write_all(&checksum, sizeof(checksum));

        ++record_count_;

        // Periodic fsync — batches disk writes, stays within latency budget
        if (record_count_ % WAL_FSYNC_INTERVAL == 0) {
            force_sync();
        }
    }

    void write_all(const void* buf, size_t len) {
        const auto* ptr = static_cast<const uint8_t*>(buf);
        size_t written = 0;
        while (written < len) {
            ssize_t n = write(fd_, ptr + written, len - written);
            if (n <= 0) {
                throw std::runtime_error("WAL: write failed — fatal");
            }
            written += static_cast<size_t>(n);
        }
    }

    void recover_wal_sequence() {
        // Re-open read-only to find last sequence number
        int rfd = open(path_.c_str(), O_RDONLY);
        if (rfd < 0) return;

        // Skip file header (64 bytes)
        lseek(rfd, 64, SEEK_SET);

        WalRecordHeader hdr;
        uint64_t last_seq = 0;

        while (true) {
            ssize_t n = read(rfd, &hdr, sizeof(hdr));
            if (n < static_cast<ssize_t>(sizeof(hdr))) break;
            if (hdr.magic != WAL_MAGIC) break;

            last_seq = hdr.sequence;
            // Skip payload + checksum
            lseek(rfd, static_cast<off_t>(hdr.length + 4), SEEK_CUR);
        }

        close(rfd);
        wal_seq_ = last_seq;
    }
};

} // namespace predmarket
