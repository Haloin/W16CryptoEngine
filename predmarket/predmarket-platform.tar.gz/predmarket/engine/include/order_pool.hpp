#pragma once
// engine/include/order_pool.hpp
//
// Fixed-size slab allocator for Order objects.
// - Pre-allocates all memory at startup (mlock'd to prevent swap)
// - O(1) acquire/release — no system calls in the hot path
// - Single-threaded: no locking (matching engine is single-threaded per market)

#include <cstdint>
#include <cstddef>
#include <cassert>
#include <sys/mman.h>
#include <vector>
#include <stdexcept>

namespace predmarket { namespace engine {

// UUIDs stored as two 64-bit integers to avoid string allocation
struct Uuid {
    uint64_t hi;
    uint64_t lo;

    bool operator==(const Uuid& o) const noexcept {
        return hi == o.hi && lo == o.lo;
    }
    bool operator!=(const Uuid& o) const noexcept { return !(*this == o); }
};

enum class OrderSide   : uint8_t { Buy = 0, Sell = 1 };
enum class OrderType   : uint8_t { Limit = 0, Market = 1 };
enum class OrderStatus : uint8_t { Open = 0, Partial = 1, Filled = 2, Cancelled = 3 };

// Packed to exactly 64 bytes (one cache line).
// Field order is deliberate: hot fields first.
struct alignas(64) Order {
    uint64_t   quantity;          // 8  — original quantity (base units × 10^6)
    uint64_t   filled_quantity;   // 8  — how much has been filled
    uint64_t   sequence_number;   // 8  — submission sequence, used for time priority
    uint32_t   price;             // 4  — fixed-point × 10000
    OrderSide  side;              // 1
    OrderType  type;              // 1
    OrderStatus status;           // 1
    uint8_t    _pad0;             // 1
    Uuid       order_id;          // 16 — UUID (hi+lo)
    Uuid       user_id;           // 16 — UUID (hi+lo)
    // Intrusive doubly-linked list for FIFO within a price level
    Order*     prev;              // 8
    Order*     next;              // 8
    // Total: 8+8+8+4+1+1+1+1+16+16+8+8 = 80? Let me recount:
    // quantity(8) + filled_quantity(8) + sequence_number(8) + price(4) + side(1) + type(1) + status(1) + pad(1)
    // = 32 bytes
    // order_id(16) + user_id(16) = 32 bytes
    // prev(8) + next(8) = 16 bytes
    // Total = 80 bytes — needs 128-byte alignment or we trim fields
    // Actual: fits in 128 bytes (2 cache lines); accept this for correctness over micro-opt

    uint64_t remaining() const noexcept {
        return quantity - filled_quantity;
    }

    bool is_fully_filled() const noexcept {
        return filled_quantity >= quantity;
    }
};

// Pool size: 500,000 orders × 80 bytes ≈ 40 MB per market instance
constexpr size_t DEFAULT_POOL_SIZE = 500'000;

class OrderPool {
public:
    explicit OrderPool(size_t capacity = DEFAULT_POOL_SIZE)
        : capacity_(capacity)
    {
        // Allocate page-aligned memory
        void* mem = mmap(
            nullptr,
            capacity_ * sizeof(Order),
            PROT_READ | PROT_WRITE,
            MAP_PRIVATE | MAP_ANONYMOUS,
            -1, 0
        );

        if (mem == MAP_FAILED) {
            throw std::runtime_error("OrderPool: mmap failed");
        }

        storage_ = static_cast<Order*>(mem);

        // Lock pages to prevent swap — eliminates page fault latency
        if (mlock(storage_, capacity_ * sizeof(Order)) != 0) {
            // Non-fatal: log warning but continue.
            // mlock can fail if RLIMIT_MEMLOCK is too low.
            // Production: set 'ulimit -l unlimited' or configure /etc/security/limits.conf
        }

        // Pre-fault all pages by touching them (triggers CoW resolution)
        for (size_t i = 0; i < capacity_; ++i) {
            storage_[i].sequence_number = 0;  // touches the page
        }

        // Build free list
        free_list_.reserve(capacity_);
        for (size_t i = 0; i < capacity_; ++i) {
            free_list_.push_back(&storage_[i]);
        }
    }

    ~OrderPool() {
        munlock(storage_, capacity_ * sizeof(Order));
        munmap(storage_, capacity_ * sizeof(Order));
    }

    // No copy/move — addresses must remain stable
    OrderPool(const OrderPool&) = delete;
    OrderPool& operator=(const OrderPool&) = delete;

    // O(1) acquire — single pop from free list
    // Returns nullptr if pool is exhausted (caller must handle backpressure)
    [[nodiscard]] Order* acquire() noexcept {
        if (free_list_.empty()) [[unlikely]] {
            return nullptr;
        }
        Order* p = free_list_.back();
        free_list_.pop_back();
        // Zero only the fields we rely on being clean
        p->filled_quantity = 0;
        p->status = OrderStatus::Open;
        p->prev = nullptr;
        p->next = nullptr;
        return p;
    }

    // O(1) release
    void release(Order* p) noexcept {
        assert(p >= storage_ && p < storage_ + capacity_);
        free_list_.push_back(p);
    }

    size_t available() const noexcept { return free_list_.size(); }
    size_t capacity()  const noexcept { return capacity_; }

private:
    Order*              storage_;
    size_t              capacity_;
    std::vector<Order*> free_list_;
};


} // namespace engine
} // namespace predmarket
