// engine/src/order_book.cpp
//
// Implementation of OrderBook matching logic.
// Price-time priority: best price first, FIFO within price level.

#include "order_book.hpp"
#include <stdexcept>

namespace predmarket { namespace engine {

ExecutionResult OrderBook::submit(
    Uuid      order_id,
    Uuid      user_id,
    OrderSide side,
    OrderType type,
    uint32_t  price,
    uint64_t  quantity,
    uint64_t  sequence_number
) {
    // Allocate from pool — O(1), no heap
    Order* taker = pool_.acquire();
    if (!taker) [[unlikely]] {
        // Pool exhausted — caller must reject order with backpressure signal
        throw std::runtime_error("OrderPool exhausted");
    }

    taker->order_id        = order_id;
    taker->user_id         = user_id;
    taker->side            = side;
    taker->type            = type;
    taker->price           = price;
    taker->quantity        = quantity;
    taker->filled_quantity = 0;
    taker->sequence_number = sequence_number;
    taker->status          = OrderStatus::Open;
    taker->prev            = nullptr;
    taker->next            = nullptr;

    // Check for duplicate order_id
    if (order_index_.count(order_id)) [[unlikely]] {
        pool_.release(taker);
        // Return empty result — Rust layer already deduplicates via Redis,
        // but defence in depth is free here.
        return ExecutionResult{ {}, 0, quantity, false };
    }

    ExecutionResult result;
    bool is_market = (type == OrderType::Market);

    if (side == OrderSide::Buy) {
        result = match_buy(taker, price, is_market);
    } else {
        result = match_sell(taker, price, is_market);
    }

    result.filled_qty    = taker->filled_quantity;
    result.remaining_qty = taker->remaining();

    // If partially or unfilled limit order: add to resting book
    if (!is_market && taker->remaining() > 0) {
        add_to_book(taker);
        result.order_resting = true;
    } else {
        // Fully filled or market order with nothing left — release immediately
        if (!result.order_resting) {
            pool_.release(taker);
        }
    }

    ++depth_seq_;
    return result;
}

ExecutionResult OrderBook::match_buy(Order* taker, uint32_t limit_price, bool is_market) {
    ExecutionResult result;
    result.order_resting = false;

    // Walk asks from cheapest upward
    auto it = asks_.begin();
    while (it != asks_.end() && taker->remaining() > 0) {
        uint32_t ask_price = it->first;

        // Price check: for limit orders, taker pays at most limit_price
        if (!is_market && ask_price > limit_price) {
            break;  // No more matchable prices
        }

        BookPriceLevel& level = it->second;

        // Walk FIFO queue at this price level
        while (level.head && taker->remaining() > 0) {
            Order* maker = level.head;

            // Self-trade prevention: skip if same user
            // (Prediction markets typically allow self-trading, but this is configurable)
            // if (maker->user_id == taker->user_id) { break; }

            uint64_t fill_qty = std::min(taker->remaining(), maker->remaining());

            // Generate fill
            FillResult fill;
            fill.fill_id         = next_fill_id();
            fill.maker_order_id  = maker->order_id;
            fill.taker_order_id  = taker->order_id;
            fill.maker_user_id   = maker->user_id;
            fill.taker_user_id   = taker->user_id;
            fill.price           = ask_price;  // Fill at maker's (resting) price
            fill.quantity        = fill_qty;
            fill.aggressor_side  = OrderSide::Buy;
            result.fills.push_back(fill);

            // Update quantities
            taker->filled_quantity += fill_qty;
            maker->filled_quantity += fill_qty;
            level.total_qty        -= fill_qty;

            if (maker->is_fully_filled()) {
                maker->status = OrderStatus::Filled;
                level.remove(maker);
                order_index_.erase(maker->order_id);
                pool_.release(maker);
                --ask_order_count_;
            } else {
                maker->status = OrderStatus::Partial;
            }

            if (taker->is_fully_filled()) {
                taker->status = OrderStatus::Filled;
            }
        }

        if (level.empty()) {
            it = asks_.erase(it);
        } else {
            ++it;
        }
    }

    return result;
}

ExecutionResult OrderBook::match_sell(Order* taker, uint32_t limit_price, bool is_market) {
    ExecutionResult result;
    result.order_resting = false;

    // Walk bids from highest downward
    auto it = bids_.begin();
    while (it != bids_.end() && taker->remaining() > 0) {
        uint32_t bid_price = it->first;

        // Price check: seller wants at least limit_price
        if (!is_market && bid_price < limit_price) {
            break;
        }

        BookPriceLevel& level = it->second;

        while (level.head && taker->remaining() > 0) {
            Order* maker = level.head;

            uint64_t fill_qty = std::min(taker->remaining(), maker->remaining());

            FillResult fill;
            fill.fill_id         = next_fill_id();
            fill.maker_order_id  = maker->order_id;
            fill.taker_order_id  = taker->order_id;
            fill.maker_user_id   = maker->user_id;
            fill.taker_user_id   = taker->user_id;
            fill.price           = bid_price;
            fill.quantity        = fill_qty;
            fill.aggressor_side  = OrderSide::Sell;
            result.fills.push_back(fill);

            taker->filled_quantity += fill_qty;
            maker->filled_quantity += fill_qty;
            level.total_qty        -= fill_qty;

            if (maker->is_fully_filled()) {
                maker->status = OrderStatus::Filled;
                level.remove(maker);
                order_index_.erase(maker->order_id);
                pool_.release(maker);
                --bid_order_count_;
            } else {
                maker->status = OrderStatus::Partial;
            }

            if (taker->is_fully_filled()) {
                taker->status = OrderStatus::Filled;
            }
        }

        if (level.empty()) {
            it = bids_.erase(it);
        } else {
            ++it;
        }
    }

    return result;
}

void OrderBook::add_to_book(Order* o) {
    if (o->side == OrderSide::Buy) {
        bids_[o->price].push_back(o);
        ++bid_order_count_;
    } else {
        asks_[o->price].push_back(o);
        ++ask_order_count_;
    }
    order_index_[o->order_id] = o;
}

bool OrderBook::cancel(Uuid order_id) {
    auto it = order_index_.find(order_id);
    if (it == order_index_.end()) {
        return false;  // Order not found (already filled or never existed)
    }

    Order* o = it->second;
    remove_from_book(o);
    order_index_.erase(it);
    o->status = OrderStatus::Cancelled;
    pool_.release(o);
    ++depth_seq_;
    return true;
}

void OrderBook::remove_from_book(Order* o) {
    if (o->side == OrderSide::Buy) {
        auto it = bids_.find(o->price);
        if (it != bids_.end()) {
            it->second.remove(o);
            if (it->second.empty()) bids_.erase(it);
            --bid_order_count_;
        }
    } else {
        auto it = asks_.find(o->price);
        if (it != asks_.end()) {
            it->second.remove(o);
            if (it->second.empty()) asks_.erase(it);
            --ask_order_count_;
        }
    }
}

std::vector<OrderBook::DepthLevel> OrderBook::bid_levels(size_t max_levels) const {
    std::vector<DepthLevel> result;
    result.reserve(std::min(max_levels, bids_.size()));
    for (auto& [price, level] : bids_) {
        if (result.size() >= max_levels) break;
        result.push_back({ price, level.total_qty, level.order_count });
    }
    return result;
}

std::vector<OrderBook::DepthLevel> OrderBook::ask_levels(size_t max_levels) const {
    std::vector<DepthLevel> result;
    result.reserve(std::min(max_levels, asks_.size()));
    for (auto& [price, level] : asks_) {
        if (result.size() >= max_levels) break;
        result.push_back({ price, level.total_qty, level.order_count });
    }
    return result;
}

} // namespace engine
} // namespace predmarket
