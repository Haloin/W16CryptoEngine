// engine/src/main.cpp
//
// Matching Engine Entry Point.
//
// Lifecycle:
//   1. Parse CLI args (--market-id, --nats-url, --wal-path, --port)
//   2. Initialize OrderPool (pre-fault memory)
//   3. Replay WAL → rebuild order book
//   4. Connect to NATS
//   5. Resume consumption from last WAL sequence
//   6. Main loop: fetch → match → WAL → publish fills → ACK
//   7. Metrics HTTP server on separate thread (read-only)
//
// Single-threaded matching loop. CPU affinity set via --cpu-affinity flag.

#include "order_book.hpp"
#include "order_pool.hpp"
#include "wal.hpp"
#include "metrics.hpp"
#include "orders_generated.h"
#include "fills_generated.h"
#include "market_data_generated.h"

#include <flatbuffers/flatbuffers.h>
#include <iostream>
#include <string>
#include <cstring>
#include <csignal>
#include <atomic>
#include <thread>
#include <chrono>
#include <sstream>
#include <iomanip>

// POSIX / Linux
#include <unistd.h>
#include <sched.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

using namespace predmarket::engine;  // engine-internal types


// NATS C client (cnats)
// Install: apt-get install libnats-dev  OR  build from github.com/nats-io/nats.c
// We include a simplified NATS interface below to avoid requiring the full library
// in the build test. Replace with real cnats calls in production.
//
// #include <nats/nats.h>

namespace predmarket {

static std::atomic<bool> g_running{true};

void signal_handler(int sig) {
    std::cerr << "[engine] received signal " << sig << ", shutting down\n";
    g_running.store(false, std::memory_order_release);
}

// ─────────────────────────────────────────────────────────────────────────────
// Minimal NATS stub — replace with real cnats in production
// Provides the same interface so the rest of the code compiles and tests pass.
// ─────────────────────────────────────────────────────────────────────────────
namespace nats_stub {

struct Msg {
    std::vector<uint8_t> data;
    std::string          subject;
    std::string          reply;
    bool                 valid = false;
};

struct Connection {
    bool connected = false;
    std::string url;
};

struct Consumer {
    std::string stream;
    std::string subject;
    // In test mode, returns canned messages from a queue
    std::vector<Msg> test_queue;
    size_t test_pos = 0;

    Msg fetch(int timeout_ms) {
        if (test_pos < test_queue.size()) {
            return test_queue[test_pos++];
        }
        // Signal no more messages
        Msg m; m.valid = false;
        return m;
    }

    void ack(const Msg&) { /* stub */ }
    void nack(const Msg&) { /* stub */ }
};

bool publish(Connection&, const std::string& subject,
             const uint8_t* data, size_t len) {
    (void)subject; (void)data; (void)len;
    return true;
}

} // namespace nats_stub

// ─────────────────────────────────────────────────────────────────────────────
// FlatBuffers serialization helpers
// ─────────────────────────────────────────────────────────────────────────────

std::vector<uint8_t> build_fill_event(
    const FillResult& fill,
    const Uuid& market_id,
    uint64_t seq,
    uint64_t ts_ns
) {
    flatbuffers::FlatBufferBuilder fbb(256);

    auto fill_event = predmarket::CreateFillEvent(
        fbb,
        fill.fill_id.hi, fill.fill_id.lo,
        market_id.hi, market_id.lo,
        fill.maker_order_id.hi, fill.maker_order_id.lo,
        fill.taker_order_id.hi, fill.taker_order_id.lo,
        fill.maker_user_id.hi, fill.maker_user_id.lo,
        fill.taker_user_id.hi, fill.taker_user_id.lo,
        static_cast<predmarket::AggressorSide>(fill.aggressor_side == engine::OrderSide::Buy ? 0 : 1),
        fill.price,
        fill.quantity,
        seq,
        ts_ns
    );

    fbb.Finish(fill_event);
    return { fbb.GetBufferPointer(), fbb.GetBufferPointer() + fbb.GetSize() };
}

std::vector<uint8_t> build_depth_update(
    const Uuid& market_id,
    const std::vector<OrderBook::DepthLevel>& bids,
    const std::vector<OrderBook::DepthLevel>& asks,
    uint64_t seq,
    uint64_t ts_ns
) {
    flatbuffers::FlatBufferBuilder fbb(1024);

    // Use the 3-arg FlatBuffers PriceLevel constructor (price, quantity, count)
    std::vector<predmarket::PriceLevel> fb_bids, fb_asks;
    for (auto& b : bids)
        fb_bids.emplace_back(b.price, b.total_qty, b.order_count);
    for (auto& a : asks)
        fb_asks.emplace_back(a.price, a.total_qty, a.order_count);

    auto bids_vec = fbb.CreateVectorOfStructs(fb_bids);
    auto asks_vec = fbb.CreateVectorOfStructs(fb_asks);

    auto depth = predmarket::CreateDepthUpdate(
        fbb,
        market_id.hi, market_id.lo,
        predmarket::DepthUpdateType_Delta,
        seq,
        bids_vec,
        asks_vec,
        ts_ns
    );

    fbb.Finish(depth);
    return { fbb.GetBufferPointer(), fbb.GetBufferPointer() + fbb.GetSize() };
}

// ─────────────────────────────────────────────────────────────────────────────
// WAL payload builders
// ─────────────────────────────────────────────────────────────────────────────

uint64_t now_ns() {
    using namespace std::chrono;
    return static_cast<uint64_t>(
        duration_cast<nanoseconds>(steady_clock::now().time_since_epoch()).count()
    );
}

WalNewOrderPayload make_wal_order(
    const predmarket::OrderSubmitEvent* ev,
    const Uuid& market_id
) {
    WalNewOrderPayload p{};
    p.sequence_number = ev->sequence_number();
    p.order_id_hi     = ev->order_id_hi();
    p.order_id_lo     = ev->order_id_lo();
    p.user_id_hi      = ev->user_id_hi();
    p.user_id_lo      = ev->user_id_lo();
    p.market_id_hi    = market_id.hi;
    p.market_id_lo    = market_id.lo;
    p.price           = ev->price();
    p.quantity        = ev->quantity();
    p.side            = static_cast<uint8_t>(ev->side());
    p.order_type      = static_cast<uint8_t>(ev->order_type());
    return p;
}

// ─────────────────────────────────────────────────────────────────────────────
// Metrics HTTP server (separate thread, read-only)
// ─────────────────────────────────────────────────────────────────────────────

void run_metrics_server(EngineMetrics& metrics,
                        const std::string& market_id,
                        uint16_t port) {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) return;

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(port);

    if (bind(server_fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        close(server_fd);
        return;
    }
    listen(server_fd, 8);

    while (g_running.load(std::memory_order_relaxed)) {
        // Non-blocking accept with 1s timeout
        fd_set fds; FD_ZERO(&fds); FD_SET(server_fd, &fds);
        timeval tv{1, 0};
        if (select(server_fd + 1, &fds, nullptr, nullptr, &tv) <= 0) continue;

        int client = accept(server_fd, nullptr, nullptr);
        if (client < 0) continue;

        // Read request (we only care about GET /metrics)
        char buf[512]; recv(client, buf, sizeof(buf), 0);

        std::string body = metrics.render_prometheus(market_id);
        std::ostringstream resp;
        resp << "HTTP/1.1 200 OK\r\n"
             << "Content-Type: text/plain; version=0.0.4\r\n"
             << "Content-Length: " << body.size() << "\r\n"
             << "Connection: close\r\n\r\n"
             << body;

        std::string r = resp.str();
        send(client, r.c_str(), r.size(), MSG_NOSIGNAL);
        close(client);
    }

    close(server_fd);
}

// ─────────────────────────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────────────────────────

struct Config {
    std::string market_id_str = "test-market-1";
    std::string nats_url      = "nats://localhost:4222";
    std::string wal_path      = "/tmp/engine_wal.bin";
    uint16_t    metrics_port  = 8081;
    int         cpu_affinity  = -1;  // -1 = no pinning
    size_t      pool_size     = 500'000;
};

Config parse_args(int argc, char** argv) {
    Config cfg;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--market-id"     && i+1 < argc) cfg.market_id_str = argv[++i];
        else if (arg == "--nats-url" && i+1 < argc) cfg.nats_url      = argv[++i];
        else if (arg == "--wal-path" && i+1 < argc) cfg.wal_path      = argv[++i];
        else if (arg == "--port"     && i+1 < argc) cfg.metrics_port  = static_cast<uint16_t>(std::stoi(argv[++i]));
        else if (arg == "--cpu"      && i+1 < argc) cfg.cpu_affinity  = std::stoi(argv[++i]);
        else if (arg == "--pool-size"&& i+1 < argc) cfg.pool_size     = static_cast<size_t>(std::stoul(argv[++i]));
    }
    return cfg;
}

// Simple string-to-UUID encoding (hash of string for determinism in tests)
Uuid market_id_from_string(const std::string& s) {
    uint64_t h = 0xcbf29ce484222325ULL;
    for (char c : s) {
        h ^= static_cast<uint8_t>(c);
        h *= 0x100000001b3ULL;
    }
    return Uuid{ h, h ^ 0xdeadbeefcafeULL };
}

} // namespace predmarket

// ─────────────────────────────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────────────────────────────

int main(int argc, char** argv) {
    using namespace predmarket;

    std::signal(SIGINT,  signal_handler);
    std::signal(SIGTERM, signal_handler);

    Config cfg = parse_args(argc, argv);

    // CPU affinity pinning
    if (cfg.cpu_affinity >= 0) {
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(cfg.cpu_affinity, &cpuset);
        if (pthread_setaffinity_np(pthread_self(), sizeof(cpuset), &cpuset) != 0) {
            std::cerr << "[engine] WARNING: could not set CPU affinity\n";
        } else {
            std::cerr << "[engine] Pinned to CPU " << cfg.cpu_affinity << "\n";
        }
    }

    Uuid market_id = market_id_from_string(cfg.market_id_str);

    std::cerr << "[engine] Starting for market: " << cfg.market_id_str << "\n";
    std::cerr << "[engine] WAL path: " << cfg.wal_path << "\n";
    std::cerr << "[engine] NATS URL: " << cfg.nats_url << "\n";

    // 1. Initialize subsystems
    EngineMetrics metrics;
    OrderPool     pool(cfg.pool_size);
    OrderBook     book(pool, market_id);

    std::cerr << "[engine] OrderPool initialized: " << pool.capacity()
              << " orders (" << (pool.capacity() * sizeof(Order) / 1024 / 1024) << " MB)\n";

    // 2. Open WAL
    Wal wal(cfg.wal_path);
    std::cerr << "[engine] WAL opened. Last sequence: " << wal.last_sequence() << "\n";

    // 3. WAL replay (in production: read records and re-submit to book)
    // Simplified here: the WAL stores all order/fill events so full replay
    // rebuilds the book. Implementation detail for production hardening.
    // TODO: implement WalReader that iterates records and re-populates book

    // 4. NATS connection (stub in build — replace with real cnats)
    nats_stub::Connection nats_conn;
    nats_conn.url       = cfg.nats_url;
    nats_conn.connected = true;

    nats_stub::Consumer order_consumer;
    order_consumer.stream  = "ORDERS";
    order_consumer.subject = "orders.submit." + cfg.market_id_str;

    std::cerr << "[engine] Connected to NATS (stub). Listening on: "
              << order_consumer.subject << "\n";

    // 5. Start metrics server on background thread
    std::thread metrics_thread(
        run_metrics_server,
        std::ref(metrics),
        cfg.market_id_str,
        cfg.metrics_port
    );
    metrics_thread.detach();

    std::cerr << "[engine] Metrics server on port " << cfg.metrics_port << "\n";
    std::cerr << "[engine] Entering main loop\n";

    // ─────────────────────────────────────────────────────────────────────────
    // 6. Main matching loop
    // ─────────────────────────────────────────────────────────────────────────
    uint64_t fill_publish_seq = 0;

    while (g_running.load(std::memory_order_acquire)) {
        auto loop_start = std::chrono::steady_clock::now();

        nats_stub::Msg msg = order_consumer.fetch(100 /* timeout_ms */);

        if (!msg.valid) {
            // No message — idle spin with a short sleep to avoid burning CPU
            std::this_thread::sleep_for(std::chrono::microseconds(100));
            continue;
        }

        // ── Decode FlatBuffer ────────────────────────────────────────────────
        const auto* ev = flatbuffers::GetRoot<predmarket::OrderSubmitEvent>(
            msg.data.data()
        );

        if (!ev) [[unlikely]] {
            std::cerr << "[engine] Malformed FlatBuffer on subject: "
                      << msg.subject << "\n";
            order_consumer.ack(msg);
            continue;
        }

        // ── WAL write BEFORE matching (crash safety) ────────────────────────
        WalNewOrderPayload wal_payload = make_wal_order(ev, market_id);
        wal.append_new_order(wal_payload);
        metrics.wal_records.fetch_add(1, std::memory_order_relaxed);

        // ── Build Order identifiers ──────────────────────────────────────────
        Uuid order_id{ ev->order_id_hi(), ev->order_id_lo() };
        Uuid user_id { ev->user_id_hi(),  ev->user_id_lo()  };

        engine::OrderSide side = (static_cast<int>(ev->side()) == 0)
                         ? engine::OrderSide::Buy : engine::OrderSide::Sell;
        engine::OrderType type = (static_cast<int>(ev->order_type()) == 1)
                         ? engine::OrderType::Market : engine::OrderType::Limit;

        // ── Match ────────────────────────────────────────────────────────────
        ExecutionResult result;
        try {
            result = book.submit(
                order_id, user_id, side, type,
                ev->price(), ev->quantity(),
                ev->sequence_number()
            );
        } catch (const std::runtime_error& ex) {
            // Pool exhausted — backpressure
            std::cerr << "[engine] BACKPRESSURE: " << ex.what() << "\n";
            order_consumer.nack(msg);
            metrics.orders_rejected.fetch_add(1, std::memory_order_relaxed);
            continue;
        }

        metrics.orders_processed.fetch_add(1, std::memory_order_relaxed);

        // ── Publish fills ────────────────────────────────────────────────────
        uint64_t ts = now_ns();
        for (const auto& fill : result.fills) {
            ++fill_publish_seq;

            // WAL fill record
            WalFillPayload wfp{};
            wfp.fill_id_hi        = fill.fill_id.hi;
            wfp.fill_id_lo        = fill.fill_id.lo;
            wfp.maker_order_id_hi = fill.maker_order_id.hi;
            wfp.maker_order_id_lo = fill.maker_order_id.lo;
            wfp.taker_order_id_hi = fill.taker_order_id.hi;
            wfp.taker_order_id_lo = fill.taker_order_id.lo;
            wfp.maker_user_id_hi  = fill.maker_user_id.hi;
            wfp.maker_user_id_lo  = fill.maker_user_id.lo;
            wfp.taker_user_id_hi  = fill.taker_user_id.hi;
            wfp.taker_user_id_lo  = fill.taker_user_id.lo;
            wfp.price             = fill.price;
            wfp.quantity          = fill.quantity;
            wfp.aggressor_side    = fill.aggressor_side == engine::OrderSide::Buy ? 0 : 1;
            wfp.sequence          = fill_publish_seq;
            wfp.timestamp_ns      = ts;
            wal.append_fill(wfp);

            // Serialize and publish to NATS
            auto fill_buf = build_fill_event(fill, market_id, fill_publish_seq, ts);
            std::string fill_subject = "executions.fills." + cfg.market_id_str;
            nats_stub::publish(nats_conn, fill_subject,
                               fill_buf.data(), fill_buf.size());

            metrics.fills_generated.fetch_add(1, std::memory_order_relaxed);
        }

        // ── Publish depth update ─────────────────────────────────────────────
        auto depth_buf = build_depth_update(
            market_id,
            book.bid_levels(10),
            book.ask_levels(10),
            book.depth_sequence(),
            ts
        );
        std::string depth_subject = "marketdata.depth." + cfg.market_id_str;
        nats_stub::publish(nats_conn, depth_subject,
                           depth_buf.data(), depth_buf.size());

        // ── Update metrics snapshot ──────────────────────────────────────────
        metrics.bid_book_size.store(book.bid_order_count(), std::memory_order_relaxed);
        metrics.ask_book_size.store(book.ask_order_count(), std::memory_order_relaxed);
        metrics.pool_available.store(pool.available(),       std::memory_order_relaxed);

        // ── ACK only AFTER WAL write is complete ─────────────────────────────
        order_consumer.ack(msg);

        // ── Loop latency measurement ─────────────────────────────────────────
        auto loop_end = std::chrono::steady_clock::now();
        uint64_t latency_ns = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                loop_end - loop_start
            ).count()
        );
        metrics.loop_latency_ns.record(latency_ns);
    }

    std::cerr << "[engine] Shutdown complete. "
              << "Processed: " << metrics.orders_processed.load()
              << " orders, " << metrics.fills_generated.load() << " fills\n";

    wal.force_sync();
    return 0;
}
