# bots/ml_model/model.py
#
# Probability estimation model for prediction market fair value.
#
# Architecture:
#   - Offline training: batch historical trade data from the REST API
#   - Online inference: called each market-making cycle (< 1ms target)
#   - No direct DB/NATS access — all data sourced from the public API
#
# Model: Bayesian Beta distribution updated with observed trade prices.
# This is intentionally simple and interpretable.
# For production: replace with a gradient-boosted model (XGBoost/LightGBM)
# trained on order flow imbalance, trade momentum, and time-to-resolution.

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np


# ── Beta Distribution Model ───────────────────────────────────────────────────

@dataclass
class BetaModel:
    """
    Bayesian Beta distribution over a binary outcome probability.

    Prior: Beta(alpha, beta). Default alpha=beta=2 → prior mean=0.5, weak.
    Update rule: each observed trade at price p updates:
        alpha += p       (trade at 0.7 → adds 0.7 weight to YES)
        beta  += (1 - p) (same trade → adds 0.3 weight to NO)

    Posterior mean = alpha / (alpha + beta) → fair value estimate.
    Posterior std  → uncertainty / confidence interval.
    """
    alpha: float = 2.0
    beta:  float = 2.0

    @property
    def mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def variance(self) -> float:
        n = self.alpha + self.beta
        return (self.alpha * self.beta) / (n * n * (n + 1))

    @property
    def std(self) -> float:
        return math.sqrt(self.variance)

    @property
    def confidence_interval_95(self) -> tuple[float, float]:
        """Approximate 95% CI using normal approximation."""
        z = 1.96
        m, s = self.mean, self.std
        return (max(0.001, m - z * s), min(0.999, m + z * s))

    def update(self, trade_price: float, weight: float = 1.0) -> None:
        """Incorporate a new trade observation."""
        if not 0.0 < trade_price < 1.0:
            return
        self.alpha += weight * trade_price
        self.beta  += weight * (1.0 - trade_price)

    def update_batch(self, prices: list[float], weights: Optional[list[float]] = None) -> None:
        ws = weights or [1.0] * len(prices)
        for p, w in zip(prices, ws):
            self.update(p, w)


# ── Order Flow Imbalance Feature ──────────────────────────────────────────────

@dataclass
class OrderFlowImbalance:
    """
    Tracks buy vs sell pressure from recent order flow.
    OFI > 0 → buy-side pressure → price likely to increase.
    OFI < 0 → sell-side pressure → price likely to decrease.
    """
    window: int = 50  # rolling window of recent trades

    _buy_volume:  float = field(default=0.0, repr=False)
    _sell_volume: float = field(default=0.0, repr=False)
    _history:     list  = field(default_factory=list, repr=False)

    def add_trade(self, side: str, quantity: float) -> None:
        self._history.append((side, quantity))
        if len(self._history) > self.window:
            old_side, old_qty = self._history.pop(0)
            if old_side == "BUY":
                self._buy_volume  -= old_qty
            else:
                self._sell_volume -= old_qty

        if side == "BUY":
            self._buy_volume  += quantity
        else:
            self._sell_volume += quantity

    @property
    def imbalance(self) -> float:
        """Returns OFI in [-1, +1]. 0 = balanced."""
        total = self._buy_volume + self._sell_volume
        if total == 0:
            return 0.0
        return (self._buy_volume - self._sell_volume) / total

    @property
    def adjustment(self) -> float:
        """
        Price adjustment from OFI.
        Maps imbalance ∈ [-1, 1] → price nudge ∈ [-0.02, +0.02].
        """
        return self.imbalance * 0.02


# ── Combined Fair Value Estimator ─────────────────────────────────────────────

@dataclass
class FairValueEstimator:
    """
    Combines:
      1. Beta posterior (long-term prior from trade history)
      2. OFI adjustment (short-term momentum)
      3. Time decay (approaching resolution → lower uncertainty)

    Output: fair_value ∈ (0, 1) with confidence interval.
    Inference time target: < 0.1ms (all pure Python/numpy).
    """
    market_id: str
    beta_model: BetaModel = field(default_factory=lambda: BetaModel(alpha=2.0, beta=2.0))
    ofi:        OrderFlowImbalance = field(default_factory=OrderFlowImbalance)

    # Time-to-resolution in seconds (None = unknown)
    resolution_ts: Optional[float] = None
    _created_ts:   float = field(default_factory=time.time, repr=False)

    def ingest_trade(self, price: float, quantity: float, side: str) -> None:
        """Process a new fill from the WebSocket stream."""
        # Recency weighting: newer trades get higher weight
        # (exponential decay with half-life = 100 trades)
        n = len(self.ofi._history)
        weight = max(0.1, math.exp(-n / 100.0))
        self.beta_model.update(price, weight=weight)
        self.ofi.add_trade(side, quantity)

    def ingest_trades_bulk(self, trades: list[dict]) -> None:
        """Bulk ingest from REST /trades endpoint (on startup)."""
        for t in trades:
            price = t.get("price", 0)
            qty   = t.get("quantity", 1)
            side  = "BUY" if t.get("aggressor_side", 0) == 0 else "SELL"
            if isinstance(price, int):
                price = price / 10_000.0  # fixed-point → float
            if isinstance(qty, int):
                qty = qty / 1_000_000.0   # base units → shares
            self.ingest_trade(price, qty, side)

    def estimate(self) -> dict:
        """
        Return fair value estimate and metadata.
        < 0.1ms guaranteed (pure arithmetic).
        """
        t0 = time.perf_counter_ns()

        # Base estimate from Beta posterior
        base = self.beta_model.mean

        # OFI momentum adjustment (short-term)
        ofi_adj = self.ofi.adjustment

        # Time-decay adjustment: near resolution → pull toward extremes
        # (less uncertainty → alpha/beta grow proportionally)
        time_adj = 0.0
        if self.resolution_ts:
            elapsed   = time.time() - self._created_ts
            remaining = max(1.0, self.resolution_ts - time.time())
            total     = max(1.0, self.resolution_ts - self._created_ts)
            pct_elapsed = elapsed / total
            # Pull estimate toward current best guess as time runs out
            if pct_elapsed > 0.8:
                time_adj = (base - 0.5) * 0.1 * (pct_elapsed - 0.8) / 0.2

        fair = max(0.001, min(0.999, base + ofi_adj + time_adj))
        ci_lo, ci_hi = self.beta_model.confidence_interval_95
        elapsed_ns = time.perf_counter_ns() - t0

        return {
            "fair_value":          round(fair, 6),
            "beta_posterior_mean": round(base, 6),
            "ofi_adjustment":      round(ofi_adj, 6),
            "time_adjustment":     round(time_adj, 6),
            "ci_95_lo":            round(ci_lo, 6),
            "ci_95_hi":            round(ci_hi, 6),
            "uncertainty_std":     round(self.beta_model.std, 6),
            "ofi_imbalance":       round(self.ofi.imbalance, 4),
            "trade_count":         len(self.ofi._history),
            "inference_ns":        elapsed_ns,
        }

    @property
    def fair_value(self) -> float:
        return self.estimate()["fair_value"]


# ── Standalone model test ─────────────────────────────────────────────────────

if __name__ == "__main__":
    import random

    print("=== FairValueEstimator Self-Test ===\n")
    model = FairValueEstimator(market_id="test-btc-100k")

    # Simulate a market where true probability is ~0.70
    TRUE_PROB = 0.70
    random.seed(42)
    trades = [
        {"price": int(round(random.gauss(TRUE_PROB, 0.05), 4) * 10_000),
         "quantity": random.randint(500_000, 2_000_000),
         "aggressor_side": 0 if random.random() < TRUE_PROB else 1}
        for _ in range(200)
    ]
    model.ingest_trades_bulk(trades)

    result = model.estimate()
    print(f"True probability:      {TRUE_PROB:.4f}")
    print(f"Estimated fair value:  {result['fair_value']:.4f}")
    print(f"95% CI:                [{result['ci_95_lo']:.4f}, {result['ci_95_hi']:.4f}]")
    print(f"Uncertainty (std):     {result['uncertainty_std']:.4f}")
    print(f"OFI imbalance:         {result['ofi_imbalance']:+.4f}")
    print(f"Inference time:        {result['inference_ns']} ns")

    error = abs(result['fair_value'] - TRUE_PROB)
    ci_contains_true = result['ci_95_lo'] <= TRUE_PROB <= result['ci_95_hi']
    print(f"\nEstimation error:     {error:.4f}  {'✓ good' if error < 0.05 else '✗ poor'}")
    print(f"CI contains true:     {'✓ yes' if ci_contains_true else '✗ no'}")
    print(f"Inference < 1000ns:   {'✓ yes' if result['inference_ns'] < 1000 else '✗ no'}")
