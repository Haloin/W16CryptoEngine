# bots/api_client.py
#
# Async HTTP + WebSocket client for the PredMarket API.
# ALL Python bot interactions go exclusively through this client.
# No direct database, Redis, or NATS access from Python ever.
#
# Enforces the architecture boundary:
#   Python → REST/WebSocket → Rust API → (NATS) → C++ Engine

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import AsyncIterator, Callable, Optional

import aiohttp
import websockets

logger = logging.getLogger(__name__)


@dataclass
class OrderBookDepth:
    market_id: str
    bids: list[dict]   # [{"price": float, "quantity": float, "count": int}]
    asks: list[dict]
    sequence: int

    @property
    def best_bid(self) -> Optional[float]:
        return self.bids[0]["price"] if self.bids else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.asks[0]["price"] if self.asks else None

    @property
    def mid_price(self) -> Optional[float]:
        if self.best_bid and self.best_ask:
            return (self.best_bid + self.best_ask) / 2
        return None

    @property
    def spread(self) -> Optional[float]:
        if self.best_bid and self.best_ask:
            return self.best_ask - self.best_bid
        return None


@dataclass
class Fill:
    fill_id: str
    market_id: str
    price: float
    quantity: float
    aggressor_side: str
    timestamp_ns: int


@dataclass
class OrderResponse:
    order_id: str
    sequence_number: int
    status: str  # "ACCEPTED"


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"HTTP {status}: {message}")


class PredMarketClient:
    """
    Async REST + WebSocket client.
    Thread-safe: one aiohttp.ClientSession shared across all requests.

    Usage:
        async with PredMarketClient("http://localhost:8080", token) as client:
            depth = await client.get_depth(market_id)
            resp  = await client.submit_order(market_id, "BUY", "LIMIT", 0.65, 10.0)
    """

    def __init__(self, base_url: str, token: str, timeout_secs: float = 5.0):
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = aiohttp.ClientTimeout(total=timeout_secs)
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self) -> "PredMarketClient":
        self._session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self._token}"},
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, *_) -> None:
        if self._session:
            await self._session.close()

    # ── Auth ─────────────────────────────────────────────────────────────────

    @classmethod
    async def get_token(cls, base_url: str, user_id: str) -> str:
        """Exchange user_id for a JWT token."""
        async with aiohttp.ClientSession() as s:
            async with s.post(
                f"{base_url}/v1/auth/token",
                json={"user_id": user_id},
            ) as r:
                data = await r.json()
                if r.status != 200:
                    raise ApiError(r.status, str(data))
                return data["token"]

    # ── Markets ───────────────────────────────────────────────────────────────

    async def list_markets(self) -> list[dict]:
        data = await self._get("/v1/markets")
        return data["markets"]

    async def get_market(self, market_id: str) -> dict:
        return (await self._get(f"/v1/markets/{market_id}"))["market"]

    async def get_depth(self, market_id: str) -> OrderBookDepth:
        data = await self._get(f"/v1/markets/{market_id}/depth")
        d = data["depth"]
        return OrderBookDepth(
            market_id=d["market_id"],
            bids=d["bids"],
            asks=d["asks"],
            sequence=d["sequence"],
        )

    async def get_trades(self, market_id: str) -> list[dict]:
        data = await self._get(f"/v1/markets/{market_id}/trades")
        return data["trades"]

    # ── Orders ────────────────────────────────────────────────────────────────

    async def submit_order(
        self,
        market_id:  str,
        side:       str,    # "BUY" or "SELL"
        order_type: str,    # "LIMIT" or "MARKET"
        quantity:   float,  # shares
        price:      Optional[float] = None,
        order_id:   Optional[str]   = None,
    ) -> OrderResponse:
        """
        Submit a new order. Returns as soon as it is accepted into the queue.
        Fill notification arrives via WebSocket.

        order_id is a client-generated idempotency key (UUID v4).
        If omitted, a new UUID is generated automatically.
        """
        oid = order_id or str(uuid.uuid4())
        payload = {
            "order_id":   oid,
            "market_id":  market_id,
            "side":       side.upper(),
            "order_type": order_type.upper(),
            "quantity":   quantity,
        }
        if price is not None:
            payload["price"] = round(price, 4)

        data = await self._post("/v1/orders", payload)
        return OrderResponse(
            order_id=data["order_id"],
            sequence_number=data["sequence_number"],
            status=data["status"],
        )

    async def cancel_order(self, order_id: str) -> dict:
        return await self._delete(f"/v1/orders/{order_id}")

    async def get_order(self, order_id: str) -> dict:
        return (await self._get(f"/v1/orders/{order_id}"))["order"]

    # ── User ──────────────────────────────────────────────────────────────────

    async def get_balance(self) -> dict:
        return await self._get("/v1/users/me/balance")

    async def get_my_orders(self) -> list[dict]:
        return (await self._get("/v1/users/me/orders"))["orders"]

    # ── WebSocket depth stream ────────────────────────────────────────────────

    async def stream_depth(
        self,
        market_id: str,
        on_update: Callable[[dict], None],
        reconnect_delay: float = 1.0,
    ) -> None:
        """
        Subscribe to real-time order book depth updates.
        Calls on_update(msg_dict) for each message received.
        Reconnects automatically on disconnect.

        This is a long-running coroutine; cancel it to stop.
        """
        ws_url = (
            self._base_url.replace("http://", "ws://")
                          .replace("https://", "wss://")
            + f"/v1/ws/{market_id}"
        )
        while True:
            try:
                async with websockets.connect(
                    ws_url,
                    extra_headers={"Authorization": f"Bearer {self._token}"},
                    ping_interval=20,
                    ping_timeout=10,
                ) as ws:
                    logger.info("WebSocket connected for market %s", market_id)
                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                            on_update(msg)
                        except json.JSONDecodeError:
                            logger.warning("Non-JSON WS message: %r", raw)
            except (websockets.ConnectionClosed, OSError) as e:
                logger.warning("WS disconnected (%s), reconnecting in %ss", e, reconnect_delay)
                await asyncio.sleep(reconnect_delay)

    # ── Health ────────────────────────────────────────────────────────────────

    async def health(self) -> dict:
        return await self._get("/v1/health")

    # ── HTTP helpers ──────────────────────────────────────────────────────────

    async def _get(self, path: str) -> dict:
        assert self._session, "Use as async context manager"
        async with self._session.get(self._base_url + path) as r:
            return await self._parse(r)

    async def _post(self, path: str, body: dict) -> dict:
        assert self._session, "Use as async context manager"
        async with self._session.post(self._base_url + path, json=body) as r:
            return await self._parse(r)

    async def _delete(self, path: str) -> dict:
        assert self._session, "Use as async context manager"
        async with self._session.delete(self._base_url + path) as r:
            return await self._parse(r)

    @staticmethod
    async def _parse(r: aiohttp.ClientResponse) -> dict:
        text = await r.text()
        if r.status >= 400:
            raise ApiError(r.status, text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"raw": text}
