# bots/tests/test_bots.py
#
# Unit tests for Python bot layer.
# All tests are offline — no real API server required.
# Mock the REST calls; test logic only.

import asyncio
import math
import sys
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, "/home/claude/predmarket")

from bots.api_client import OrderBookDepth, OrderResponse, PredMarketClient
from bots.market_maker.bot import BotState, MarketMakerBot, MarketMakerConfig
from bots.ml_model.model import BetaModel, FairValueEstimator, OrderFlowImbalance


# ── Helper: run async tests ───────────────────────────────────────────────────

def run_async(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


# ── BetaModel tests ───────────────────────────────────────────────────────────

class TestBetaModel(unittest.TestCase):

    def test_prior_mean_is_half(self):
        m = BetaModel(alpha=2.0, beta=2.0)
        self.assertAlmostEqual(m.mean, 0.5, places=5)

    def test_update_shifts_toward_observation(self):
        m = BetaModel(alpha=2.0, beta=2.0)
        for _ in range(100):
            m.update(0.80)
        self.assertGreater(m.mean, 0.70)
        self.assertLess(m.mean, 0.95)

    def test_confidence_interval_contains_mean(self):
        m = BetaModel(alpha=5.0, beta=3.0)
        lo, hi = m.confidence_interval_95
        self.assertLessEqual(lo, m.mean)
        self.assertGreaterEqual(hi, m.mean)

    def test_variance_decreases_with_more_data(self):
        m = BetaModel(alpha=2.0, beta=2.0)
        initial_var = m.variance
        for _ in range(200):
            m.update(0.6)
        self.assertLess(m.variance, initial_var)

    def test_update_batch_equals_sequential(self):
        prices = [0.6, 0.7, 0.55, 0.65, 0.72]
        m1 = BetaModel(); m2 = BetaModel()
        m1.update_batch(prices)
        for p in prices:
            m2.update(p)
        self.assertAlmostEqual(m1.mean, m2.mean, places=10)

    def test_extreme_observations_clamped_by_estimator(self):
        m = BetaModel(alpha=2.0, beta=2.0)
        m.update(1.5)   # out of range — should be ignored
        m.update(-0.1)  # out of range — should be ignored
        self.assertAlmostEqual(m.mean, 0.5, places=5)


# ── OrderFlowImbalance tests ──────────────────────────────────────────────────

class TestOFI(unittest.TestCase):

    def test_balanced_flow_is_zero(self):
        ofi = OrderFlowImbalance()
        for _ in range(20):
            ofi.add_trade("BUY", 100)
            ofi.add_trade("SELL", 100)
        self.assertAlmostEqual(ofi.imbalance, 0.0, places=3)

    def test_all_buys_is_positive(self):
        ofi = OrderFlowImbalance()
        for _ in range(10):
            ofi.add_trade("BUY", 100)
        self.assertAlmostEqual(ofi.imbalance, 1.0, places=3)

    def test_adjustment_bounded(self):
        ofi = OrderFlowImbalance()
        for _ in range(50):
            ofi.add_trade("BUY", 500)
        self.assertLessEqual(abs(ofi.adjustment), 0.02)

    def test_window_rolling(self):
        ofi = OrderFlowImbalance(window=10)
        # Add 10 buys (fills window)
        for _ in range(10):
            ofi.add_trade("BUY", 100)
        self.assertAlmostEqual(ofi.imbalance, 1.0, places=3)
        # Add 10 sells (should push out the buys)
        for _ in range(10):
            ofi.add_trade("SELL", 100)
        self.assertAlmostEqual(ofi.imbalance, -1.0, places=2)


# ── FairValueEstimator tests ──────────────────────────────────────────────────

class TestFairValueEstimator(unittest.TestCase):

    def test_prior_is_half(self):
        m = FairValueEstimator("test")
        self.assertAlmostEqual(m.fair_value, 0.5, places=2)

    def test_converges_toward_truth(self):
        import random
        random.seed(42)
        model = FairValueEstimator("test")
        TRUE = 0.75
        trades = [
            {
                "price": int(round(random.gauss(TRUE, 0.04), 4) * 10_000),
                "quantity": 1_000_000,
                "aggressor_side": 0,
            }
            for _ in range(300)
        ]
        model.ingest_trades_bulk(trades)
        error = abs(model.fair_value - TRUE)
        self.assertLess(error, 0.08, f"Model error {error:.4f} too high")

    def test_inference_under_1ms(self):
        model = FairValueEstimator("test")
        result = model.estimate()
        # Allow 5ms in CI (CI machines are slow)
        self.assertLess(result["inference_ns"], 5_000_000)

    def test_bulk_ingest_fixed_point_conversion(self):
        model = FairValueEstimator("test")
        # Fixed-point price 6500 = 0.65
        trades = [{"price": 6500, "quantity": 1_000_000, "aggressor_side": 0}] * 50
        model.ingest_trades_bulk(trades)
        self.assertGreater(model.fair_value, 0.5)

    def test_estimate_keys_present(self):
        model = FairValueEstimator("test")
        result = model.estimate()
        required = [
            "fair_value", "ci_95_lo", "ci_95_hi",
            "uncertainty_std", "ofi_imbalance", "inference_ns",
        ]
        for k in required:
            self.assertIn(k, result)

    def test_ofi_buy_pressure_raises_estimate(self):
        m1 = FairValueEstimator("test")
        m2 = FairValueEstimator("test")
        for _ in range(30):
            m1.ofi.add_trade("BUY", 100)
            m2.ofi.add_trade("SELL", 100)
        self.assertGreater(m1.fair_value, m2.fair_value)


# ── OrderBookDepth tests ──────────────────────────────────────────────────────

class TestOrderBookDepth(unittest.TestCase):

    def make_depth(self) -> OrderBookDepth:
        return OrderBookDepth(
            market_id="m1",
            bids=[{"price": 0.64, "quantity": 1000, "count": 3},
                  {"price": 0.63, "quantity": 500,  "count": 1}],
            asks=[{"price": 0.66, "quantity": 800,  "count": 2},
                  {"price": 0.67, "quantity": 300,  "count": 1}],
            sequence=42,
        )

    def test_best_bid_ask(self):
        d = self.make_depth()
        self.assertAlmostEqual(d.best_bid, 0.64)
        self.assertAlmostEqual(d.best_ask, 0.66)

    def test_mid_price(self):
        d = self.make_depth()
        self.assertAlmostEqual(d.mid_price, 0.65, places=5)

    def test_spread(self):
        d = self.make_depth()
        self.assertAlmostEqual(d.spread, 0.02, places=5)

    def test_empty_book(self):
        d = OrderBookDepth("m", [], [], 0)
        self.assertIsNone(d.best_bid)
        self.assertIsNone(d.best_ask)
        self.assertIsNone(d.mid_price)


# ── MarketMaker logic tests ───────────────────────────────────────────────────

class TestMarketMakerQuoteLogic(unittest.TestCase):
    """
    Test the quote computation logic without any network calls.
    """

    def make_bot(self, **overrides) -> MarketMakerBot:
        defaults = dict(market_id="test", base_spread=0.04, min_spread=0.01, fair_value=0.50)
        defaults.update(overrides)
        cfg = MarketMakerConfig(**defaults)
        client = MagicMock()
        bot = MarketMakerBot(client, cfg)
        return bot

    def test_neutral_quotes_symmetric(self):
        bot = self.make_bot()
        bot._state.position = 0.0
        bid, ask = bot._compute_quotes(0.50)
        self.assertAlmostEqual((bid + ask) / 2, 0.50, places=5)
        self.assertAlmostEqual(ask - bid, 0.04, places=5)

    def test_long_position_skews_quotes_down(self):
        bot = self.make_bot(max_inventory=1000.0)
        bot._state.position = 500.0  # 50% of max → max skew
        bid_neutral, ask_neutral = bot._compute_quotes(0.50)
        bot._state.position = 0.0
        bid_zero, ask_zero = bot._compute_quotes(0.50)
        # Long position should shift both quotes down (want to sell)
        self.assertLess(bid_neutral, bid_zero)
        self.assertLess(ask_neutral, ask_zero)

    def test_short_position_skews_quotes_up(self):
        bot = self.make_bot(max_inventory=1000.0)
        bot._state.position = -500.0
        bid_short, ask_short = bot._compute_quotes(0.50)
        bot._state.position = 0.0
        bid_zero, ask_zero = bot._compute_quotes(0.50)
        self.assertGreater(bid_short, bid_zero)
        self.assertGreater(ask_short, ask_zero)

    def test_spread_never_below_minimum(self):
        bot = self.make_bot(base_spread=0.001, min_spread=0.01)
        bid, ask = bot._compute_quotes(0.50)
        self.assertGreaterEqual(ask - bid, 0.01)

    def test_fill_updates_position(self):
        bot = self.make_bot()
        self.assertEqual(bot.state.position, 0.0)
        bot.update_fill("BUY",  100.0, 0.65)
        bot.update_fill("BUY",  50.0,  0.66)
        bot.update_fill("SELL", 30.0,  0.67)
        self.assertAlmostEqual(bot.state.position, 120.0)
        self.assertEqual(bot.state.fill_count, 3)

    def test_fair_value_uses_mid_when_depth_available(self):
        bot = self.make_bot(fair_value=0.50)
        bot._depth = OrderBookDepth("test", 
            bids=[{"price": 0.70}], asks=[{"price": 0.74}], sequence=1)
        fv = bot._compute_fair_value()
        # Should move toward mid (0.72), not stay at 0.50
        self.assertGreater(fv, 0.50)


# ── Integration smoke test ────────────────────────────────────────────────────

class TestApiClientContract(unittest.TestCase):
    """
    Verify that OrderResponse and OrderBookDepth parse correctly
    from mock HTTP responses (no server needed).
    """

    def test_order_response_fields(self):
        resp = OrderResponse(
            order_id="abc-123",
            sequence_number=42,
            status="ACCEPTED",
        )
        self.assertEqual(resp.order_id, "abc-123")
        self.assertEqual(resp.sequence_number, 42)
        self.assertEqual(resp.status, "ACCEPTED")

    def test_depth_from_raw_dict(self):
        raw = {
            "market_id": "m1",
            "bids": [{"price": 0.60, "quantity": 1000, "count": 2}],
            "asks": [{"price": 0.62, "quantity": 500,  "count": 1}],
            "sequence": 7,
        }
        d = OrderBookDepth(**raw)
        self.assertAlmostEqual(d.mid_price, 0.61)
        self.assertAlmostEqual(d.spread, 0.02)


# ── Runner ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    unittest.main(verbosity=2)
