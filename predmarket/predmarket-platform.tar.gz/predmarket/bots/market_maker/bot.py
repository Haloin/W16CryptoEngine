# bots/market_maker/bot.py
#
# Market Making Bot.
#
# Strategy:
#   1. Maintain a target spread around the estimated fair value.
#   2. Submit a bid and ask each cycle at (fair_value ± half_spread).
#   3. Cancel-and-replace on each cycle to stay at current prices.
#   4. Skew quotes based on inventory to manage position risk.
#
# Inventory skew:
#   If position > max_inventory/2: widen ask, tighten bid (want to sell)
#   If position < -max_inventory/2: tighten ask, widen bid (want to buy)
#
# This bot ONLY interacts via the REST API. No direct engine access.
# All decision logic is here; execution is delegated to api_client.py.

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from bots.api_client import ApiError, OrderBookDepth, PredMarketClient

logger = logging.getLogger(__name__)


@dataclass
class MarketMakerConfig:
    market_id:       str
    base_spread:     float = 0.02    # 2% spread around fair value
    min_spread:      float = 0.005   # never quote tighter than 0.5%
    order_size:      float = 100.0   # shares per side
    max_inventory:   float = 1000.0  # shares, absolute position limit
    cycle_ms:        int   = 500     # quote refresh interval (ms)
    max_retries:     int   = 3       # per-order retry attempts
    fair_value:      float = 0.5     # initial fair value estimate


@dataclass
class BotState:
    position:     float = 0.0   # net shares (positive = long)
    active_bid:   Optional[str] = None  # current resting bid order_id
    active_ask:   Optional[str] = None  # current resting ask order_id
    cycle_count:  int   = 0
    fill_count:   int   = 0
    pnl_estimate: float = 0.0


class MarketMakerBot:
    """
    Async market making bot.
    Runs a continuous quote-refresh loop.

    Usage:
        config = MarketMakerConfig(market_id="...", fair_value=0.65)
        bot    = MarketMakerBot(client, config)
        await  bot.run()
    """

    def __init__(self, client: PredMarketClient, config: MarketMakerConfig):
        self._client = client
        self._cfg    = config
        self._state  = BotState()
        self._depth: Optional[OrderBookDepth] = None
        self._running = False

    # ── Public ────────────────────────────────────────────────────────────────

    async def run(self) -> None:
        """Main loop. Runs until cancelled."""
        self._running = True
        logger.info(
            "MarketMaker starting | market=%s spread=%.3f size=%.0f",
            self._cfg.market_id, self._cfg.base_spread, self._cfg.order_size,
        )

        # Run depth stream and quote loop concurrently
        async with asyncio.TaskGroup() as tg:
            tg.create_task(self._depth_stream_loop())
            tg.create_task(self._quote_loop())

    # ── Loops ─────────────────────────────────────────────────────────────────

    async def _depth_stream_loop(self) -> None:
        """Subscribe to WS depth and update self._depth."""
        def on_update(msg: dict) -> None:
            if "bids" in msg and "asks" in msg:
                self._depth = OrderBookDepth(
                    market_id=self._cfg.market_id,
                    bids=msg.get("bids", []),
                    asks=msg.get("asks", []),
                    sequence=msg.get("sequence", 0),
                )

        await self._client.stream_depth(self._cfg.market_id, on_update)

    async def _quote_loop(self) -> None:
        """Refresh quotes every cycle_ms milliseconds."""
        while self._running:
            t0 = time.monotonic()
            try:
                await self._refresh_quotes()
                self._state.cycle_count += 1
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error("Quote cycle error: %s", e)

            elapsed = time.monotonic() - t0
            sleep_s = max(0.0, self._cfg.cycle_ms / 1000.0 - elapsed)
            await asyncio.sleep(sleep_s)

    # ── Core logic ────────────────────────────────────────────────────────────

    async def _refresh_quotes(self) -> None:
        fair = self._compute_fair_value()
        bid_price, ask_price = self._compute_quotes(fair)

        # Clamp to valid prediction market range
        bid_price = max(0.01, min(0.98, round(bid_price, 4)))
        ask_price = max(0.02, min(0.99, round(ask_price, 4)))

        if bid_price >= ask_price:
            logger.warning("Inverted quotes bid=%.4f ask=%.4f, skipping", bid_price, ask_price)
            return

        # Cancel stale resting orders first
        await self._cancel_active()

        # Submit new two-sided quotes
        if abs(self._state.position) < self._cfg.max_inventory:
            await self._place_order("BUY",  bid_price)
            await self._place_order("SELL", ask_price)

        logger.debug(
            "Cycle %d | fair=%.4f bid=%.4f ask=%.4f pos=%.0f",
            self._state.cycle_count, fair, bid_price, ask_price,
            self._state.position,
        )

    def _compute_fair_value(self) -> float:
        """
        Fair value estimate.
        Uses order book mid-price if available, otherwise config default.
        In production: replace with ML model output (see ml_model/model.py).
        """
        if self._depth and self._depth.mid_price:
            # Exponential moving average of mid-price
            alpha = 0.2
            self._cfg.fair_value = (
                alpha * self._depth.mid_price
                + (1 - alpha) * self._cfg.fair_value
            )
        return self._cfg.fair_value

    def _compute_quotes(self, fair: float) -> tuple[float, float]:
        """
        Compute bid/ask prices with inventory skew.

        Inventory skew formula:
            skew = (position / max_inventory) * (base_spread / 2)
            bid  = fair - half_spread - skew
            ask  = fair + half_spread - skew

        When long (positive position):
            skew > 0 → bid and ask both shift down → more likely to sell
        When short (negative position):
            skew < 0 → bid and ask both shift up → more likely to buy
        """
        skew = (self._state.position / self._cfg.max_inventory) * (self._cfg.base_spread / 2)
        half = max(self._cfg.min_spread / 2, self._cfg.base_spread / 2)

        bid = fair - half - skew
        ask = fair + half - skew
        return bid, ask

    async def _place_order(self, side: str, price: float) -> None:
        for attempt in range(self._cfg.max_retries):
            try:
                resp = await self._client.submit_order(
                    market_id=self._cfg.market_id,
                    side=side,
                    order_type="LIMIT",
                    price=price,
                    quantity=self._cfg.order_size,
                )
                if side == "BUY":
                    self._state.active_bid = resp.order_id
                else:
                    self._state.active_ask = resp.order_id
                return
            except ApiError as e:
                if e.status == 503 and attempt < self._cfg.max_retries - 1:
                    await asyncio.sleep(0.1 * (attempt + 1))
                    continue
                logger.error("Order placement failed: %s", e)
                return

    async def _cancel_active(self) -> None:
        """Cancel both resting quotes if they exist."""
        for oid in [self._state.active_bid, self._state.active_ask]:
            if oid:
                try:
                    await self._client.cancel_order(oid)
                except ApiError:
                    pass  # Already filled or expired
        self._state.active_bid = None
        self._state.active_ask = None

    def update_fill(self, side: str, quantity: float, price: float) -> None:
        """Called externally when a fill arrives via WebSocket."""
        delta = quantity if side == "BUY" else -quantity
        self._state.position    += delta
        self._state.fill_count  += 1
        self._state.pnl_estimate -= delta * price  # simplified mark-to-zero
        logger.info(
            "Fill: %s %.0f @ %.4f | position=%.0f",
            side, quantity, price, self._state.position,
        )

    @property
    def state(self) -> BotState:
        return self._state
