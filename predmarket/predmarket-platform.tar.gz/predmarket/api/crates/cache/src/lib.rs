// crates/cache/src/lib.rs
//
// Redis cache wrapper. Provides:
//   - Balance cache (write-through from positions)
//   - Session/token cache
//   - Idempotency key store
//   - Market status cache
//
// In this build we provide an in-memory stub that satisfies the same
// interface. In production, replace InMemoryCache with RedisCache backed
// by the `fred` crate.

use common::{AppError, AppResult, MarketId, OrderId, UserId};
use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::time::{Duration, Instant};

#[derive(Clone)]
struct Entry {
    value:   String,
    expires: Option<Instant>,
}

impl Entry {
    fn is_expired(&self) -> bool {
        self.expires.map(|e| Instant::now() > e).unwrap_or(false)
    }
}

#[derive(Clone)]
pub struct CacheClient {
    store: Arc<RwLock<HashMap<String, Entry>>>,
}

impl CacheClient {
    pub fn new() -> Self {
        Self { store: Arc::new(RwLock::new(HashMap::new())) }
    }

    /// SET key value [EX seconds]. Returns previous value if any.
    pub fn set(&self, key: &str, value: &str, ttl: Option<Duration>) -> AppResult<()> {
        let entry = Entry {
            value:   value.to_string(),
            expires: ttl.map(|d| Instant::now() + d),
        };
        self.store.write().unwrap().insert(key.to_string(), entry);
        Ok(())
    }

    /// GET key. Returns None if missing or expired.
    pub fn get(&self, key: &str) -> AppResult<Option<String>> {
        let store = self.store.read().unwrap();
        Ok(store.get(key).and_then(|e| {
            if e.is_expired() { None } else { Some(e.value.clone()) }
        }))
    }

    /// SET NX (only set if not exists). Returns true if key was set.
    pub fn set_nx(&self, key: &str, value: &str, ttl: Duration) -> AppResult<bool> {
        let mut store = self.store.write().unwrap();
        if store.get(key).map(|e| !e.is_expired()).unwrap_or(false) {
            return Ok(false);
        }
        store.insert(key.to_string(), Entry {
            value:   value.to_string(),
            expires: Some(Instant::now() + ttl),
        });
        Ok(true)
    }

    /// DEL key.
    pub fn del(&self, key: &str) -> AppResult<()> {
        self.store.write().unwrap().remove(key);
        Ok(())
    }

    // ── Domain helpers ───────────────────────────────────────────────────────

    /// Check and register order idempotency key.
    /// Returns true if this is a new order (not a duplicate).
    pub fn register_order_id(&self, order_id: &OrderId) -> AppResult<bool> {
        let key = format!("idem:{}", order_id.0);
        self.set_nx(&key, "1", Duration::from_secs(86400))
    }

    /// Cache market status string.
    pub fn set_market_status(&self, market_id: &MarketId, status: &str) -> AppResult<()> {
        let key = format!("market:{}:status", market_id.0);
        self.set(&key, status, Some(Duration::from_secs(5)))
    }

    pub fn get_market_status(&self, market_id: &MarketId) -> AppResult<Option<String>> {
        let key = format!("market:{}:status", market_id.0);
        self.get(&key)
    }
}

impl Default for CacheClient {
    fn default() -> Self { Self::new() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_get_roundtrip() {
        let c = CacheClient::new();
        c.set("k", "v", None).unwrap();
        assert_eq!(c.get("k").unwrap(), Some("v".into()));
    }

    #[test]
    fn set_nx_prevents_overwrite() {
        let c = CacheClient::new();
        let ok = c.set_nx("k", "first", Duration::from_secs(60)).unwrap();
        assert!(ok);
        let ok2 = c.set_nx("k", "second", Duration::from_secs(60)).unwrap();
        assert!(!ok2);
        assert_eq!(c.get("k").unwrap(), Some("first".into()));
    }

    #[test]
    fn order_dedup() {
        let c = CacheClient::new();
        let oid = OrderId::new();
        assert!(c.register_order_id(&oid).unwrap());
        assert!(!c.register_order_id(&oid).unwrap()); // duplicate
    }
}
