// crates/auth/src/lib.rs
// JWT HS256 — hand-rolled with hmac + sha2 + base64 to avoid Rust edition2024 deps.
// Compatible with Rust 1.75. Drop-in replacement for jsonwebtoken in production.

use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use chrono::{Duration, Utc};
use common::{AppError, AppResult, UserId};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use uuid::Uuid;

type HmacSha256 = Hmac<Sha256>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Claims {
    pub sub:   String,
    pub iat:   i64,
    pub exp:   i64,
    pub roles: u32,
}

impl Claims {
    pub fn user_id(&self) -> AppResult<UserId> {
        Uuid::parse_str(&self.sub)
            .map(UserId)
            .map_err(|_| AppError::Unauthorized)
    }
    pub fn is_admin(&self) -> bool { self.roles & 0x01 != 0 }
    pub fn is_expired(&self) -> bool { self.exp < Utc::now().timestamp() }
}

const HEADER: &str = r#"{"alg":"HS256","typ":"JWT"}"#;

#[derive(Clone)]
pub struct JwtService {
    secret:   Vec<u8>,
    ttl_secs: i64,
}

impl JwtService {
    pub fn new(secret: &[u8], ttl_secs: i64) -> Self {
        Self { secret: secret.to_vec(), ttl_secs }
    }

    pub fn issue(&self, user_id: UserId, roles: u32) -> AppResult<String> {
        let now = Utc::now();
        let claims = Claims {
            sub:   user_id.0.to_string(),
            iat:   now.timestamp(),
            exp:   (now + Duration::seconds(self.ttl_secs)).timestamp(),
            roles,
        };
        let header_b64  = URL_SAFE_NO_PAD.encode(HEADER.as_bytes());
        let payload_b64 = URL_SAFE_NO_PAD.encode(
            serde_json::to_vec(&claims)
                .map_err(|e| AppError::Internal(e.to_string()))?.as_slice()
        );
        let signing_input = format!("{header_b64}.{payload_b64}");
        let sig = self.sign(signing_input.as_bytes())?;
        Ok(format!("{signing_input}.{sig}"))
    }

    pub fn verify(&self, token: &str) -> AppResult<Claims> {
        let parts: Vec<&str> = token.splitn(3, '.').collect();
        if parts.len() != 3 {
            return Err(AppError::Unauthorized);
        }
        let signing_input = format!("{}.{}", parts[0], parts[1]);
        let expected_sig = self.sign(signing_input.as_bytes())?;
        // Constant-time comparison
        if !constant_eq(parts[2].as_bytes(), expected_sig.as_bytes()) {
            return Err(AppError::Unauthorized);
        }
        let payload_bytes = URL_SAFE_NO_PAD.decode(parts[1])
            .map_err(|_| AppError::Unauthorized)?;
        let claims: Claims = serde_json::from_slice(&payload_bytes)
            .map_err(|_| AppError::Unauthorized)?;
        if claims.is_expired() {
            return Err(AppError::Unauthorized);
        }
        Ok(claims)
    }

    pub fn verify_bearer(&self, header_value: &str) -> AppResult<Claims> {
        let token = header_value.strip_prefix("Bearer ")
            .ok_or(AppError::Unauthorized)?;
        self.verify(token)
    }

    fn sign(&self, data: &[u8]) -> AppResult<String> {
        let mut mac = HmacSha256::new_from_slice(&self.secret)
            .map_err(|e| AppError::Internal(e.to_string()))?;
        mac.update(data);
        let result = mac.finalize().into_bytes();
        Ok(URL_SAFE_NO_PAD.encode(result))
    }
}

fn constant_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    a.iter().zip(b.iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

#[cfg(test)]
mod tests {
    use super::*;

    fn svc() -> JwtService { JwtService::new(b"test-secret-at-least-32-bytes-long!!", 3600) }

    #[test]
    fn issue_and_verify_roundtrip() {
        let svc = svc();
        let uid = UserId::new();
        let token = svc.issue(uid, 0).unwrap();
        let claims = svc.verify(&token).unwrap();
        assert_eq!(claims.user_id().unwrap(), uid);
        assert!(!claims.is_expired());
    }

    #[test]
    fn verify_bearer_strips_prefix() {
        let svc = svc();
        let uid = UserId::new();
        let token = svc.issue(uid, 0).unwrap();
        let claims = svc.verify_bearer(&format!("Bearer {token}")).unwrap();
        assert_eq!(claims.user_id().unwrap(), uid);
    }

    #[test]
    fn tampered_signature_rejected() {
        let svc = svc();
        let uid = UserId::new();
        let mut token = svc.issue(uid, 0).unwrap();
        token.push('X');
        assert!(svc.verify(&token).is_err());
    }

    #[test]
    fn expired_token_rejected() {
        let svc = JwtService::new(b"test-secret-at-least-32-bytes-long!!", -1);
        let uid = UserId::new();
        let token = svc.issue(uid, 0).unwrap();
        assert!(svc.verify(&token).is_err());
    }

    #[test]
    fn admin_role_flag() {
        let svc = svc();
        let uid = UserId::new();
        let token = svc.issue(uid, 0x01).unwrap();
        assert!(svc.verify(&token).unwrap().is_admin());
    }

    #[test]
    fn wrong_secret_rejected() {
        let svc1 = JwtService::new(b"secret-one-padded-to-32-bytes!!!", 3600);
        let svc2 = JwtService::new(b"secret-two-padded-to-32-bytes!!!", 3600);
        let token = svc1.issue(UserId::new(), 0).unwrap();
        assert!(svc2.verify(&token).is_err());
    }
}
