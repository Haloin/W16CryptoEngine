// crates/orders/src/lib.rs
//
// Order submission, validation, sequencing.
// Responsibilities:
//   - Validate all order fields (price bounds, quantity, market status)
//   - Assign monotonic sequence numbers (per-market AtomicU64)
//   - Deduplication via in-memory set (Redis in production)
//   - Publish to NATS → C++ engine
//   - NO matching logic whatsoever

use common::{
    AppError, AppResult, FixedPrice, MarketId, MarketStatus, OrderId,
    OrderRequest, OrderSide, OrderStatus, OrderType, Quantity, UserId,
};
use messaging::{NatsClient, OrderSubmitMsg, OrderCancelMsg};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, RwLock};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{info, instrument, warn};

// ── Sequence counter per market ───────────────────────────────────────────────

#[derive(Default)]
struct MarketSequencer {
    counters: HashMap<MarketId, Arc<AtomicU64>>,
}

impl MarketSequencer {
    fn next(&mut self, market_id: MarketId) -> u64 {
        self.counters
            .entry(market_id)
            .or_insert_with(|| Arc::new(AtomicU64::new(1)))
            .fetch_add(1, Ordering::Relaxed)
    }
}

// ── Deduplication (in-process; Redis in production) ──────────────────────────

struct DedupeStore {
    seen: HashMap<OrderId, ()>,
}

impl DedupeStore {
    fn new() -> Self { Self { seen: HashMap::new() } }

    /// Returns true if this is a NEW order (not seen before).
    fn register(&mut self, id: OrderId) -> bool {
        self.seen.insert(id, ()).is_none()
    }
}

// ── Market status cache (in-process stub; Redis in production) ────────────────

pub struct MarketStatusCache {
    statuses: Arc<RwLock<HashMap<MarketId, MarketStatus>>>,
}

impl MarketStatusCache {
    pub fn new() -> Self {
        Self { statuses: Arc::new(RwLock::new(HashMap::new())) }
    }

    pub fn set(&self, id: MarketId, status: MarketStatus) {
        self.statuses.write().unwrap().insert(id, status);
    }

    pub fn get(&self, id: &MarketId) -> Option<MarketStatus> {
        self.statuses.read().unwrap().get(id).copied()
    }
}

impl Default for MarketStatusCache {
    fn default() -> Self { Self::new() }
}

// ── OrderService ──────────────────────────────────────────────────────────────

pub struct OrderService {
    nats:        NatsClient,
    sequencer:   Arc<tokio::sync::Mutex<MarketSequencer>>,
    dedupe:      Arc<tokio::sync::Mutex<DedupeStore>>,
    market_cache: Arc<MarketStatusCache>,
}

impl OrderService {
    pub fn new(nats: NatsClient, market_cache: Arc<MarketStatusCache>) -> Self {
        Self {
            nats,
            sequencer:    Arc::new(tokio::sync::Mutex::new(MarketSequencer::default())),
            dedupe:       Arc::new(tokio::sync::Mutex::new(DedupeStore::new())),
            market_cache,
        }
    }

    /// Submit a new order through the full validation → sequencing → publish pipeline.
    #[instrument(skip(self), fields(
        order_id  = %req.order_id.0,
        market_id = %req.market_id.0,
        side      = ?req.side,
    ))]
    pub async fn submit(&self, user_id: UserId, req: OrderRequest) -> AppResult<u64> {
        // ── 1. Market status check ───────────────────────────────────────────
        let status = self.market_cache.get(&req.market_id)
            .ok_or_else(|| AppError::MarketNotFound(req.market_id.0.to_string()))?;

        if status != MarketStatus::Open {
            return Err(AppError::MarketNotOpen(format!("{:?}", status)));
        }

        // ── 2. Field validation ──────────────────────────────────────────────
        self.validate_order(&req)?;

        // ── 3. Deduplication ─────────────────────────────────────────────────
        {
            let mut dedupe = self.dedupe.lock().await;
            if !dedupe.register(req.order_id) {
                warn!(order_id = %req.order_id.0, "duplicate order rejected");
                return Err(AppError::DuplicateOrder(req.order_id.0.to_string()));
            }
        }

        // ── 4. Sequence number ───────────────────────────────────────────────
        let seq = {
            let mut seq = self.sequencer.lock().await;
            seq.next(req.market_id)
        };

        // ── 5. Build and publish NATS message ────────────────────────────────
        let ts_ns = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;

        let msg = OrderSubmitMsg {
            sequence_number: seq,
            order_id:        req.order_id.0.to_string(),
            market_id:       req.market_id.0.to_string(),
            user_id:         user_id.0.to_string(),
            side:            if req.side == OrderSide::Buy { 0 } else { 1 },
            order_type:      if req.order_type == OrderType::Limit { 0 } else { 1 },
            price:           req.price.map(|p| p.0).unwrap_or(0),
            quantity:        req.quantity.0,
            timestamp_ns:    ts_ns,
        };

        self.nats.publish_order(&msg).await?;

        info!(sequence = seq, "order published to NATS");
        Ok(seq)
    }

    /// Cancel a resting order.
    #[instrument(skip(self), fields(order_id = %order_id.0))]
    pub async fn cancel(
        &self,
        user_id:   UserId,
        market_id: MarketId,
        order_id:  OrderId,
    ) -> AppResult<()> {
        let ts_ns = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;

        let msg = OrderCancelMsg {
            sequence_number: 0, // cancels don't need sequencing
            order_id:        order_id.0.to_string(),
            market_id:       market_id.0.to_string(),
            user_id:         user_id.0.to_string(),
            timestamp_ns:    ts_ns,
        };

        self.nats.publish_cancel(&msg).await?;
        Ok(())
    }

    // ── Private validation ───────────────────────────────────────────────────

    fn validate_order(&self, req: &OrderRequest) -> AppResult<()> {
        // Quantity must be at least minimum
        if req.quantity.0 < Quantity::MIN.0 {
            return Err(AppError::Validation(
                format!("quantity {} below minimum {}", req.quantity.0, Quantity::MIN.0)
            ));
        }

        // Quantity maximum (10,000 shares per order)
        let max_qty = Quantity::from_shares(10_000.0);
        if req.quantity.0 > max_qty.0 {
            return Err(AppError::Validation(
                format!("quantity {} exceeds maximum {}", req.quantity.0, max_qty.0)
            ));
        }

        // Limit orders require a price
        if req.order_type == OrderType::Limit {
            match req.price {
                None => return Err(AppError::Validation(
                    "limit order requires a price".into()
                )),
                Some(p) => {
                    // Prediction market: price in (0, 1)
                    if p.0 < FixedPrice::MIN_PREDICTION.0 || p.0 > FixedPrice::MAX_PREDICTION.0 {
                        return Err(AppError::Validation(
                            format!("price {} out of bounds [0.0001, 0.9999]", p.to_f64())
                        ));
                    }
                }
            }
        }

        Ok(())
    }
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use common::{FixedPrice, MarketId, OrderId, OrderSide, OrderType, Quantity};

    fn make_req(side: OrderSide, price: Option<f64>, qty: f64) -> OrderRequest {
        OrderRequest {
            order_id:   OrderId::new(),
            market_id:  MarketId::new(),
            side,
            order_type: if price.is_some() { OrderType::Limit } else { OrderType::Market },
            price:      price.and_then(FixedPrice::from_f64),
            quantity:   Quantity::from_shares(qty),
        }
    }

    #[test]
    fn rejects_price_out_of_bounds() {
        // Manually create a service with a dummy cache; just test validation
        let cache = Arc::new(MarketStatusCache::new());
        // We can't call OrderService without NATS, so test validate_order directly
        // by constructing an instance via a helper
        let req = make_req(OrderSide::Buy, Some(1.5), 1.0); // price > 1.0 is invalid
        // FixedPrice::from_f64(1.5) returns None, so price becomes None
        // That means it would fail "limit order requires price"
        assert!(req.price.is_none());
    }

    #[test]
    fn fixed_price_roundtrip() {
        let p = FixedPrice::from_f64(0.65).unwrap();
        assert_eq!(p.0, 6500);
        assert!((p.to_f64() - 0.65).abs() < 1e-6);
    }

    #[test]
    fn quantity_conversion() {
        let q = Quantity::from_shares(2.5);
        assert_eq!(q.0, 2_500_000);
        assert!((q.to_shares() - 2.5).abs() < 1e-6);
    }

    #[test]
    fn market_status_cache_roundtrip() {
        let cache = MarketStatusCache::new();
        let mid = MarketId::new();
        cache.set(mid, MarketStatus::Open);
        assert_eq!(cache.get(&mid), Some(MarketStatus::Open));
        cache.set(mid, MarketStatus::Settled);
        assert_eq!(cache.get(&mid), Some(MarketStatus::Settled));
    }
}
