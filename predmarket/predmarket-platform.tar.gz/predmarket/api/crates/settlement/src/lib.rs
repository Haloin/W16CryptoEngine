// crates/settlement/src/lib.rs
//
// Market settlement: resolves a market YES/NO and pays out winners.

use common::{AppError, AppResult, MarketId, MarketStatus, OrderSide, UserId};
use markets::MarketService;
use positions::PositionService;
use std::sync::Arc;
use tracing::info;

pub struct SettlementService {
    markets:   Arc<MarketService>,
    positions: Arc<PositionService>,
}

impl SettlementService {
    pub fn new(markets: Arc<MarketService>, positions: Arc<PositionService>) -> Self {
        Self { markets, positions }
    }

    /// Settle a binary market.
    /// `winner_side`: BUY = YES resolved, SELL = NO resolved.
    /// Winners receive 1.0 (10_000 fixed-point) per share held.
    pub fn settle(
        &self,
        market_id:   MarketId,
        winner_side: OrderSide,
        payouts:     Vec<(UserId, i64)>, // (user_id, winning_quantity)
    ) -> AppResult<()> {
        self.markets.set_status(&market_id, MarketStatus::Settled)?;

        let mut total_payout = 0i64;
        for (user_id, qty) in payouts {
            // Payout = quantity × 1.0 = quantity (in base units)
            let payout = qty;
            self.positions.positions.write().unwrap(); // validate access
            self.positions.deposit(user_id, payout);
            total_payout += payout;
            info!(
                user_id = %user_id.0,
                payout,
                "settlement payout credited"
            );
        }

        info!(
            market_id = %market_id.0,
            ?winner_side,
            total_payout,
            "market settled"
        );
        Ok(())
    }
}
