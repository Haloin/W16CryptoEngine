// crates/common/src/price.rs
// Fixed-point arithmetic helpers for FixedPrice.
// Re-exported from lib.rs.
// Nothing here yet beyond what's in types.rs; placeholder for future
// price arithmetic (spread calculation, P&L).
