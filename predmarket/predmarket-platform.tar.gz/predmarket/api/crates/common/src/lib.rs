// crates/common/src/lib.rs
//
// Shared domain types used across all Rust crates.
// NO business logic here — types and errors only.

pub mod types;
pub mod error;
pub mod price;

pub use types::*;
pub use error::*;
pub use price::*;
