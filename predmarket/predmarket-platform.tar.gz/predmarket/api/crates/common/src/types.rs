// crates/common/src/types.rs
use rand::Rng;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

// ─── Identity ────────────────────────────────────────────────────────────────

/// Newtype wrappers enforce type-safe ID handling at compile time.
/// Prevents accidentally passing a market_id where an order_id is expected.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct UserId(pub Uuid);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct MarketId(pub Uuid);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct OrderId(pub Uuid);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct FillId(pub Uuid);

fn new_uuid() -> Uuid {
    let mut b = [0u8; 16];
    rand::thread_rng().fill(&mut b);
    b[6] = (b[6] & 0x0f) | 0x40; // version 4
    b[8] = (b[8] & 0x3f) | 0x80; // variant RFC4122
    Uuid::from_bytes(b)
}
impl UserId   { pub fn new() -> Self { Self(new_uuid()) } }
impl MarketId { pub fn new() -> Self { Self(new_uuid()) } }
impl OrderId  { pub fn new() -> Self { Self(new_uuid()) } }
impl FillId   { pub fn new() -> Self { Self(new_uuid()) } }

// ─── Price and Quantity ───────────────────────────────────────────────────────

/// Fixed-point price: internal representation is u32 = price × 10_000.
/// Range: 0.0001 to 9999.9999. Prediction markets use [0.0001, 0.9999].
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct FixedPrice(pub u32);

impl FixedPrice {
    pub const MIN_PREDICTION: Self = Self(1);     // 0.0001
    pub const MAX_PREDICTION: Self = Self(9_999); // 0.9999

    pub fn from_f64(f: f64) -> Option<Self> {
        if f <= 0.0 || f >= 1.0 { return None; }
        Some(Self((f * 10_000.0).round() as u32))
    }

    pub fn to_f64(self) -> f64 { self.0 as f64 / 10_000.0 }
}

/// Quantity in base units × 10^6. 1 share = 1_000_000.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct Quantity(pub u64);

impl Quantity {
    pub const MIN: Self = Self(1_000); // 0.001 shares minimum
    pub fn from_shares(s: f64) -> Self { Self((s * 1_000_000.0) as u64) }
    pub fn to_shares(self) -> f64 { self.0 as f64 / 1_000_000.0 }
}

// ─── Order ───────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum OrderSide { Buy, Sell }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum OrderType { Limit, Market }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum OrderStatus {
    Open, Partial, Filled, Cancelled, Rejected,
}

/// Submitted by client. Validated and sequenced by the orders crate.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderRequest {
    /// Client-generated idempotency key (UUID v4).
    pub order_id:  OrderId,
    pub market_id: MarketId,
    pub side:      OrderSide,
    pub order_type: OrderType,
    /// Required for Limit orders; None for Market orders.
    pub price:     Option<FixedPrice>,
    pub quantity:  Quantity,
}

/// Persisted order record (after validation and sequencing).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub order_id:        OrderId,
    pub market_id:       MarketId,
    pub user_id:         UserId,
    pub side:            OrderSide,
    pub order_type:      OrderType,
    pub price:           Option<FixedPrice>,
    pub quantity:        Quantity,
    pub filled_quantity: Quantity,
    pub status:          OrderStatus,
    pub sequence_number: u64,
    pub created_at:      DateTime<Utc>,
    pub updated_at:      DateTime<Utc>,
}

// ─── Fill ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Fill {
    pub fill_id:        FillId,
    pub market_id:      MarketId,
    pub maker_order_id: OrderId,
    pub taker_order_id: OrderId,
    pub maker_user_id:  UserId,
    pub taker_user_id:  UserId,
    pub price:          FixedPrice,
    pub quantity:       Quantity,
    pub aggressor_side: OrderSide,
    pub fill_seq:       u64,
    pub filled_at:      DateTime<Utc>,
}

// ─── Market ───────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum MarketStatus { Open, Paused, Settled, Cancelled }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Market {
    pub market_id:   MarketId,
    pub title:       String,
    pub description: String,
    pub status:      MarketStatus,
    pub created_at:  DateTime<Utc>,
    pub resolves_at: Option<DateTime<Utc>>,
}

// ─── Depth ────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PriceLevel {
    pub price:    FixedPrice,
    pub quantity: Quantity,
    pub count:    u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderBookDepth {
    pub market_id: MarketId,
    pub bids:      Vec<PriceLevel>,
    pub asks:      Vec<PriceLevel>,
    pub sequence:  u64,
}
