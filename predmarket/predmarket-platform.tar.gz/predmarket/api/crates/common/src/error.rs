// crates/common/src/error.rs
use thiserror::Error;

#[derive(Debug, Error)]
pub enum AppError {
    // Auth
    #[error("invalid or expired token")]
    Unauthorized,
    #[error("insufficient permissions")]
    Forbidden,

    // Validation
    #[error("validation error: {0}")]
    Validation(String),
    #[error("duplicate order: {0}")]
    DuplicateOrder(String),

    // Business logic
    #[error("insufficient balance: need {needed}, have {available}")]
    InsufficientBalance { needed: u64, available: u64 },
    #[error("market not found: {0}")]
    MarketNotFound(String),
    #[error("market not open: current status is {0}")]
    MarketNotOpen(String),
    #[error("order not found: {0}")]
    OrderNotFound(String),

    // Infrastructure
    #[error("database error: {0}")]
    Database(String),
    #[error("cache error: {0}")]
    Cache(String),
    #[error("messaging error: {0}")]
    Messaging(String),
    #[error("service unavailable: {0}")]
    ServiceUnavailable(String),

    // Internal
    #[error("internal error: {0}")]
    Internal(String),
}

impl AppError {
    pub fn http_status(&self) -> u16 {
        match self {
            Self::Unauthorized               => 401,
            Self::Forbidden                  => 403,
            Self::Validation(_)
            | Self::DuplicateOrder(_)
            | Self::MarketNotOpen(_)
            | Self::InsufficientBalance{..}  => 400,
            Self::MarketNotFound(_)
            | Self::OrderNotFound(_)         => 404,
            Self::ServiceUnavailable(_)      => 503,
            Self::Database(_)
            | Self::Cache(_)
            | Self::Messaging(_)
            | Self::Internal(_)              => 500,
        }
    }
}

pub type AppResult<T> = Result<T, AppError>;
