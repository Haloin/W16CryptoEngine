// crates/db/src/lib.rs
//
// Database abstraction layer.
// In production: backed by SQLx + PostgreSQL.
// In this build: in-memory store for integration testing without a PG instance.

use common::{
    AppError, AppResult, Fill, FillId, Market, MarketId, Order, OrderId,
    OrderStatus, UserId,
};
use std::collections::HashMap;
use std::sync::{Arc, RwLock};

#[derive(Clone, Default)]
pub struct DbClient {
    orders:  Arc<RwLock<HashMap<OrderId, Order>>>,
    fills:   Arc<RwLock<HashMap<FillId, Fill>>>,
    markets: Arc<RwLock<HashMap<MarketId, Market>>>,
}

impl DbClient {
    pub fn new() -> Self { Self::default() }

    // ── Orders ───────────────────────────────────────────────────────────────

    pub fn insert_order(&self, order: Order) -> AppResult<()> {
        self.orders.write().unwrap().insert(order.order_id, order);
        Ok(())
    }

    pub fn get_order(&self, id: &OrderId) -> AppResult<Order> {
        self.orders.read().unwrap()
            .get(id)
            .cloned()
            .ok_or_else(|| AppError::OrderNotFound(id.0.to_string()))
    }

    pub fn update_order_status(
        &self, id: &OrderId, status: OrderStatus, filled_qty: u64,
    ) -> AppResult<()> {
        let mut store = self.orders.write().unwrap();
        let order = store.get_mut(id)
            .ok_or_else(|| AppError::OrderNotFound(id.0.to_string()))?;
        order.status = status;
        order.filled_quantity.0 = filled_qty;
        Ok(())
    }

    pub fn get_open_orders_for_market(
        &self, market_id: &MarketId,
    ) -> Vec<Order> {
        self.orders.read().unwrap()
            .values()
            .filter(|o| &o.market_id == market_id
                     && matches!(o.status, OrderStatus::Open | OrderStatus::Partial))
            .cloned()
            .collect()
    }

    pub fn get_orders_for_user(&self, user_id: &UserId) -> Vec<Order> {
        self.orders.read().unwrap()
            .values()
            .filter(|o| &o.user_id == user_id)
            .cloned()
            .collect()
    }

    // ── Fills ────────────────────────────────────────────────────────────────

    pub fn insert_fill(&self, fill: Fill) -> AppResult<()> {
        self.fills.write().unwrap().insert(fill.fill_id, fill);
        Ok(())
    }

    pub fn get_fills_for_market(&self, market_id: &MarketId) -> Vec<Fill> {
        let mut fills: Vec<Fill> = self.fills.read().unwrap()
            .values()
            .filter(|f| &f.market_id == market_id)
            .cloned()
            .collect();
        fills.sort_by_key(|f| f.fill_seq);
        fills
    }

    // ── Markets ──────────────────────────────────────────────────────────────

    pub fn insert_market(&self, market: Market) -> AppResult<()> {
        self.markets.write().unwrap().insert(market.market_id, market);
        Ok(())
    }

    pub fn get_market(&self, id: &MarketId) -> AppResult<Market> {
        self.markets.read().unwrap()
            .get(id)
            .cloned()
            .ok_or_else(|| AppError::MarketNotFound(id.0.to_string()))
    }

    pub fn list_markets(&self) -> Vec<Market> {
        self.markets.read().unwrap().values().cloned().collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use common::*;
    use chrono::Utc;

    fn make_order(market_id: MarketId, user_id: UserId) -> Order {
        Order {
            order_id:        OrderId::new(),
            market_id,
            user_id,
            side:            OrderSide::Buy,
            order_type:      OrderType::Limit,
            price:           Some(FixedPrice(6500)),
            quantity:        Quantity(1_000_000),
            filled_quantity: Quantity(0),
            status:          OrderStatus::Open,
            sequence_number: 1,
            created_at:      Utc::now(),
            updated_at:      Utc::now(),
        }
    }

    #[test]
    fn insert_and_get_order() {
        let db = DbClient::new();
        let mid = MarketId::new();
        let uid = UserId::new();
        let order = make_order(mid, uid);
        let oid = order.order_id;
        db.insert_order(order).unwrap();
        let got = db.get_order(&oid).unwrap();
        assert_eq!(got.order_id, oid);
    }

    #[test]
    fn update_order_status() {
        let db = DbClient::new();
        let mid = MarketId::new();
        let uid = UserId::new();
        let order = make_order(mid, uid);
        let oid = order.order_id;
        db.insert_order(order).unwrap();
        db.update_order_status(&oid, OrderStatus::Filled, 1_000_000).unwrap();
        let got = db.get_order(&oid).unwrap();
        assert_eq!(got.status, OrderStatus::Filled);
        assert_eq!(got.filled_quantity.0, 1_000_000);
    }
}
