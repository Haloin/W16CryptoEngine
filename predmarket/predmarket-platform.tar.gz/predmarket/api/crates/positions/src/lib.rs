// crates/positions/src/lib.rs
//
// User balance and position tracking.
// Owns the balance reservation model:
//   available = total - reserved
//   On order submit:  reserved  += order_cost
//   On fill:          reserved  -= fill_cost; if buy: position += fill_qty
//   On cancel:        reserved  -= remaining_cost
//   On settlement:    payout credited to available

use common::{AppError, AppResult, FillId, MarketId, OrderId, OrderSide, UserId};
use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use tracing::info;

// ── Balance ───────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Default)]
pub struct Balance {
    /// Available for new orders (in base currency units × 10^6)
    pub available: i64,
    /// Locked in open orders
    pub reserved:  i64,
}

impl Balance {
    pub fn total(&self) -> i64 { self.available + self.reserved }

    /// Reserve `amount` from available balance.
    /// Returns Err if insufficient funds.
    pub fn reserve(&mut self, amount: i64) -> AppResult<()> {
        if self.available < amount {
            return Err(AppError::InsufficientBalance {
                needed:    amount as u64,
                available: self.available as u64,
            });
        }
        self.available -= amount;
        self.reserved  += amount;
        Ok(())
    }

    /// Release `amount` from reserved back to available.
    pub fn release(&mut self, amount: i64) {
        let actual = amount.min(self.reserved);
        self.reserved  -= actual;
        self.available += actual;
    }

    /// Credit `amount` directly to available (deposit or payout).
    pub fn credit(&mut self, amount: i64) {
        self.available += amount;
    }

    /// Consume `amount` from reserved (fill settled).
    pub fn consume_reserved(&mut self, amount: i64) {
        let actual = amount.min(self.reserved);
        self.reserved -= actual;
    }
}

// ── Position ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Default)]
pub struct Position {
    /// Net quantity held (positive = long, negative = short)
    pub quantity: i64,
    /// Average entry price (fixed-point × 10_000)
    pub avg_price: u32,
}

// ── PositionService ───────────────────────────────────────────────────────────

pub struct PositionService {
    balances:  Arc<RwLock<HashMap<UserId, Balance>>>,
    positions: Arc<RwLock<HashMap<(UserId, MarketId), Position>>>,
}

impl PositionService {
    pub fn new() -> Self {
        Self {
            balances:  Arc::new(RwLock::new(HashMap::new())),
            positions: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    // ── Balance operations ───────────────────────────────────────────────────

    pub fn deposit(&self, user_id: UserId, amount: i64) {
        self.balances.write().unwrap()
            .entry(user_id)
            .or_default()
            .credit(amount);
    }

    pub fn get_balance(&self, user_id: &UserId) -> Balance {
        self.balances.read().unwrap()
            .get(user_id)
            .cloned()
            .unwrap_or_default()
    }

    /// Reserve funds for an order (called before NATS publish).
    pub fn reserve_for_order(
        &self,
        user_id:    UserId,
        cost:       i64,
    ) -> AppResult<()> {
        self.balances.write().unwrap()
            .entry(user_id)
            .or_default()
            .reserve(cost)
    }

    /// Release reserved funds (on cancel or rejection).
    pub fn release_reservation(&self, user_id: UserId, amount: i64) {
        if let Some(bal) = self.balances.write().unwrap().get_mut(&user_id) {
            bal.release(amount);
        }
    }

    // ── Fill processing ──────────────────────────────────────────────────────

    /// Called when a fill arrives from the matching engine.
    /// Updates both buyer and seller balances and positions.
    pub fn process_fill(
        &self,
        buyer_id:  UserId,
        seller_id: UserId,
        market_id: MarketId,
        price:     u32,
        quantity:  i64,
    ) -> AppResult<()> {
        let fill_cost = (price as i64) * quantity / 10_000;

        {
            let mut balances = self.balances.write().unwrap();

            // Buyer: consume reserved (cost of purchase)
            balances.entry(buyer_id).or_default().consume_reserved(fill_cost);

            // Seller: release reservation, credit proceeds
            let seller_bal = balances.entry(seller_id).or_default();
            seller_bal.consume_reserved(fill_cost);
            seller_bal.credit(fill_cost);
        }

        {
            let mut positions = self.positions.write().unwrap();

            // Buyer gains position
            let buyer_pos = positions.entry((buyer_id, market_id)).or_default();
            let new_qty = buyer_pos.quantity + quantity;
            if new_qty != 0 {
                buyer_pos.avg_price = (
                    (buyer_pos.avg_price as i64 * buyer_pos.quantity +
                     price as i64 * quantity) / new_qty
                ) as u32;
            }
            buyer_pos.quantity = new_qty;

            // Seller reduces position
            let seller_pos = positions.entry((seller_id, market_id)).or_default();
            seller_pos.quantity -= quantity;
        }

        info!(
            buyer  = %buyer_id.0,
            seller = %seller_id.0,
            price, quantity, "fill processed"
        );
        Ok(())
    }

    pub fn get_position(&self, user_id: &UserId, market_id: &MarketId) -> Position {
        self.positions.read().unwrap()
            .get(&(*user_id, *market_id))
            .cloned()
            .unwrap_or_default()
    }
}

impl Default for PositionService {
    fn default() -> Self { Self::new() }
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reserve_and_release() {
        let svc = PositionService::new();
        let uid = UserId::new();
        svc.deposit(uid, 1_000_000);

        svc.reserve_for_order(uid, 500_000).unwrap();
        let bal = svc.get_balance(&uid);
        assert_eq!(bal.available, 500_000);
        assert_eq!(bal.reserved,  500_000);

        svc.release_reservation(uid, 500_000);
        let bal = svc.get_balance(&uid);
        assert_eq!(bal.available, 1_000_000);
        assert_eq!(bal.reserved,  0);
    }

    #[test]
    fn insufficient_balance_rejected() {
        let svc = PositionService::new();
        let uid = UserId::new();
        svc.deposit(uid, 100);
        assert!(svc.reserve_for_order(uid, 200).is_err());
    }

    #[test]
    fn fill_updates_positions() {
        let svc = PositionService::new();
        let buyer  = UserId::new();
        let seller = UserId::new();
        let market = MarketId::new();

        svc.deposit(buyer,  10_000_000);
        svc.deposit(seller, 10_000_000);
        svc.reserve_for_order(buyer,  6_500_000).unwrap(); // buying at 0.65, 1M qty
        svc.reserve_for_order(seller, 6_500_000).unwrap();

        svc.process_fill(buyer, seller, market, 6500, 1_000_000).unwrap();

        let bp = svc.get_position(&buyer, &market);
        assert_eq!(bp.quantity, 1_000_000);

        let sp = svc.get_position(&seller, &market);
        assert_eq!(sp.quantity, -1_000_000);
    }
}
