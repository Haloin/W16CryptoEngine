// crates/messaging/src/lib.rs
// NATS messaging abstraction.
// Compile with --features nats to enable real NATS (async-nats crate).
// Default build uses in-process channel stub for unit tests.

use common::{AppError, AppResult, MarketId};
use serde::{Deserialize, Serialize};
use tracing::{info, instrument};

// ── Subject helpers ───────────────────────────────────────────────────────────
pub fn subject_order_submit(market_id: &MarketId) -> String {
    format!("orders.submit.{}", market_id.0)
}
pub fn subject_order_cancel(market_id: &MarketId) -> String {
    format!("orders.cancel.{}", market_id.0)
}
pub fn subject_fills(market_id: &MarketId) -> String {
    format!("executions.fills.{}", market_id.0)
}
pub fn subject_depth(market_id: &MarketId) -> String {
    format!("marketdata.depth.{}", market_id.0)
}

// ── Wire types ────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderSubmitMsg {
    pub sequence_number: u64,
    pub order_id:        String,
    pub market_id:       String,
    pub user_id:         String,
    pub side:            u8,
    pub order_type:      u8,
    pub price:           u32,
    pub quantity:        u64,
    pub timestamp_ns:    u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderCancelMsg {
    pub sequence_number: u64,
    pub order_id:        String,
    pub market_id:       String,
    pub user_id:         String,
    pub timestamp_ns:    u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FillMsg {
    pub fill_id:         String,
    pub market_id:       String,
    pub maker_order_id:  String,
    pub taker_order_id:  String,
    pub maker_user_id:   String,
    pub taker_user_id:   String,
    pub aggressor_side:  u8,
    pub price:           u32,
    pub quantity:        u64,
    pub sequence_number: u64,
    pub timestamp_ns:    u64,
}

// ── NatsClient (real impl behind feature flag) ────────────────────────────────
#[cfg(feature = "nats")]
pub mod real {
    use super::*;

    #[derive(Clone)]
    pub struct NatsClient {
        inner: async_nats::Client,
    }

    impl NatsClient {
        pub async fn connect(url: &str) -> AppResult<Self> {
            let client = async_nats::connect(url).await
                .map_err(|e| AppError::Messaging(format!("NATS connect {url}: {e}")))?;
            info!("Connected to NATS at {url}");
            Ok(Self { inner: client })
        }

        pub async fn publish_order(&self, msg: &OrderSubmitMsg) -> AppResult<()> {
            let subject = format!("orders.submit.{}", msg.market_id);
            let payload = serde_json::to_vec(msg)
                .map_err(|e| AppError::Messaging(e.to_string()))?;
            self.inner.publish(subject, payload.into()).await
                .map_err(|e| AppError::Messaging(e.to_string()))
        }

        pub async fn publish_cancel(&self, msg: &OrderCancelMsg) -> AppResult<()> {
            let subject = format!("orders.cancel.{}", msg.market_id);
            let payload = serde_json::to_vec(msg)
                .map_err(|e| AppError::Messaging(e.to_string()))?;
            self.inner.publish(subject, payload.into()).await
                .map_err(|e| AppError::Messaging(e.to_string()))
        }
    }
}

// ── Stub NatsClient (always available, used in tests and when NATS unavailable) ─
#[derive(Clone)]
pub struct NatsClient {
    /// Captures published messages for test assertions
    published: std::sync::Arc<tokio::sync::Mutex<Vec<(String, Vec<u8>)>>>,
}

impl NatsClient {
    pub fn new_stub() -> Self {
        Self { published: std::sync::Arc::new(tokio::sync::Mutex::new(Vec::new())) }
    }

    pub async fn connect(_url: &str) -> AppResult<Self> {
        Ok(Self::new_stub())
    }

    #[instrument(skip(self, msg), fields(market = %msg.market_id))]
    pub async fn publish_order(&self, msg: &OrderSubmitMsg) -> AppResult<()> {
        let subject = format!("orders.submit.{}", msg.market_id);
        let payload = serde_json::to_vec(msg)
            .map_err(|e| AppError::Messaging(e.to_string()))?;
        info!(subject, seq = msg.sequence_number, "published order");
        self.published.lock().await.push((subject, payload));
        Ok(())
    }

    pub async fn publish_cancel(&self, msg: &OrderCancelMsg) -> AppResult<()> {
        let subject = format!("orders.cancel.{}", msg.market_id);
        let payload = serde_json::to_vec(msg)
            .map_err(|e| AppError::Messaging(e.to_string()))?;
        self.published.lock().await.push((subject, payload));
        Ok(())
    }

    /// Returns all messages published (for test assertions)
    pub async fn drain(&self) -> Vec<(String, Vec<u8>)> {
        std::mem::take(&mut *self.published.lock().await)
    }
}
