use auth::JwtService;
use cache::CacheClient;
use db::DbClient;
use markets::MarketService;
use positions::PositionService;
use std::sync::Arc;
use crate::handlers::orders::OrderServiceTrait;

#[derive(Clone)]
pub struct AppState {
    pub jwt:       JwtService,
    pub cache:     CacheClient,
    pub db:        DbClient,
    pub markets:   Arc<MarketService>,
    pub positions: Arc<PositionService>,
    pub order_svc: Arc<dyn OrderServiceTrait + Send + Sync>,
}
