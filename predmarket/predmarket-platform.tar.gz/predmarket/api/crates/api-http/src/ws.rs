// WebSocket handler for real-time order book depth and fills
use axum::{
    extract::{Path, State, WebSocketUpgrade, ws::{Message, WebSocket}},
    response::Response,
};
use std::sync::Arc;
use crate::state::AppState;
use tracing::info;

pub async fn ws_handler(
    ws: WebSocketUpgrade,
    Path(market_id): Path<String>,
    State(_state): State<Arc<AppState>>,
) -> Response {
    info!(market_id, "WebSocket upgrade");
    ws.on_upgrade(move |socket| handle_socket(socket, market_id))
}

async fn handle_socket(mut socket: WebSocket, market_id: String) {
    // Send initial connection acknowledgement
    let hello = serde_json::json!({
        "type": "connected",
        "market_id": market_id,
        "message": "Subscribed to order book depth and fills"
    });
    if socket.send(Message::Text(hello.to_string())).await.is_err() {
        return;
    }

    // In production: subscribe to NATS depth/fill subjects for this market
    // and push messages to the WebSocket in a select! loop.
    // Here: echo back any client messages (keepalive pings).
    while let Some(Ok(msg)) = socket.recv().await {
        match msg {
            Message::Ping(b) => { let _ = socket.send(Message::Pong(b)).await; }
            Message::Close(_) => break,
            _ => {}
        }
    }
}
