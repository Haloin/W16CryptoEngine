// crates/api-http/src/main.rs
//
// HTTP API Gateway — Axum 0.7
//
// Routes:
//   POST   /v1/orders              Submit a new order
//   DELETE /v1/orders/:order_id    Cancel an order
//   GET    /v1/orders/:order_id    Get order status
//   GET    /v1/markets             List all markets
//   POST   /v1/markets             Create a market (admin)
//   GET    /v1/markets/:id         Get market info
//   GET    /v1/markets/:id/depth   Order book depth snapshot
//   GET    /v1/markets/:id/trades  Recent fills
//   GET    /v1/users/me/orders     My open orders
//   GET    /v1/users/me/balance    My balance
//   GET    /v1/health              Liveness probe

mod handlers;
mod middleware;
mod state;
mod ws;

use axum::{
    routing::{delete, get, post},
    Router,
};
use std::{net::SocketAddr, sync::Arc};
use tower_http::{
    cors::CorsLayer,
    timeout::TimeoutLayer,
    trace::TraceLayer,
};
use tracing::info;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};
use std::time::Duration;

use auth::JwtService;
use cache::CacheClient;
use db::DbClient;
use markets::MarketService;
use messaging::NatsClient;
use orders::{MarketStatusCache, OrderService};
use positions::PositionService;
use state::AppState;

#[tokio::main]
async fn main() {
    // ── Tracing ──────────────────────────────────────────────────────────────
    tracing_subscriber::registry()
        .with(EnvFilter::try_from_default_env()
            .unwrap_or_else(|_| "info,api_http=debug,orders=debug".into()))
        .with(tracing_subscriber::fmt::layer().json())
        .init();

    info!("Starting PredMarket API Gateway");

    // ── Infrastructure (in-process stubs) ────────────────────────────────────
    let cache    = CacheClient::new();
    let db       = DbClient::new();
    let jwt_svc  = JwtService::new(
        std::env::var("JWT_SECRET")
            .unwrap_or_else(|_| "dev-secret-key-change-in-production!!".into())
            .as_bytes(),
        86400,
    );

    // ── Shared services ──────────────────────────────────────────────────────
    let market_cache = Arc::new(MarketStatusCache::new());
    let market_svc   = Arc::new(MarketService::new(market_cache.clone()));
    let position_svc = Arc::new(PositionService::new());

    // Seed a test market so the API is immediately usable
    let test_market = market_svc
        .create(
            "Will BTC exceed $100k by end of 2025?".into(),
            "Resolves YES if BTC/USD closes above $100,000 on any major exchange.".into(),
        )
        .unwrap();
    info!(market_id = %test_market.market_id.0, "seeded test market");

    // ── NATS connection (optional — degrade gracefully if unavailable) ────────
    let nats_url = std::env::var("NATS_URL")
        .unwrap_or_else(|_| "nats://localhost:4222".into());

    let order_svc: Arc<dyn handlers::orders::OrderServiceTrait + Send + Sync> =
        match NatsClient::connect(&nats_url).await {
            Ok(nats) => {
                info!("Connected to NATS at {nats_url}");
                Arc::new(OrderService::new(nats, market_cache.clone()))
            }
            Err(e) => {
                tracing::warn!("NATS unavailable ({e}), using stub order service");
                Arc::new(handlers::orders::StubOrderService::new(market_cache.clone()))
            }
        };

    // ── App state ─────────────────────────────────────────────────────────────
    let state = Arc::new(AppState {
        jwt:         jwt_svc,
        cache:       cache.clone(),
        db:          db.clone(),
        markets:     market_svc.clone(),
        positions:   position_svc.clone(),
        order_svc:   order_svc.clone(),
    });

    // ── Router ────────────────────────────────────────────────────────────────
    let app = Router::new()
        // Health
        .route("/v1/health", get(handlers::health::health))
        // Markets
        .route("/v1/markets",     get(handlers::markets::list_markets))
        .route("/v1/markets",     post(handlers::markets::create_market))
        .route("/v1/markets/:id", get(handlers::markets::get_market))
        .route("/v1/markets/:id/depth",  get(handlers::markets::get_depth))
        .route("/v1/markets/:id/trades", get(handlers::markets::get_trades))
        // Orders
        .route("/v1/orders",          post(handlers::orders::submit_order))
        .route("/v1/orders/:order_id", delete(handlers::orders::cancel_order))
        .route("/v1/orders/:order_id", get(handlers::orders::get_order))
        // User
        .route("/v1/users/me/orders",  get(handlers::users::my_orders))
        .route("/v1/users/me/balance", get(handlers::users::my_balance))
        // Auth
        .route("/v1/auth/token", post(handlers::auth::issue_token))
        // WebSocket
        .route("/v1/ws/:market_id", get(ws::ws_handler))
        .layer(TraceLayer::new_for_http())
        .layer(CorsLayer::permissive())
        .layer(TimeoutLayer::new(Duration::from_secs(30)))
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    info!("Listening on {addr}");

    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
