use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use uuid::Uuid;
use common::{AppError, AppResult, FixedPrice, MarketId, OrderId, OrderRequest,
             OrderSide, OrderType, Quantity, UserId};
use orders::{MarketStatusCache, OrderService};
use messaging::NatsClient;
use crate::{middleware::AuthUser, state::AppState};
use async_trait::async_trait;

// ── OrderServiceTrait (enables NATS stub fallback) ────────────────────────────

#[async_trait]
pub trait OrderServiceTrait {
    async fn submit(&self, user_id: UserId, req: OrderRequest) -> AppResult<u64>;
    async fn cancel(&self, user_id: UserId, market_id: MarketId, order_id: OrderId) -> AppResult<()>;
}

#[async_trait]
impl OrderServiceTrait for OrderService {
    async fn submit(&self, user_id: UserId, req: OrderRequest) -> AppResult<u64> {
        self.submit(user_id, req).await
    }
    async fn cancel(&self, user_id: UserId, market_id: MarketId, order_id: OrderId) -> AppResult<()> {
        self.cancel(user_id, market_id, order_id).await
    }
}

/// Stub used when NATS is unavailable — returns a fake sequence number
pub struct StubOrderService {
    cache: Arc<MarketStatusCache>,
    seq:   std::sync::atomic::AtomicU64,
}

impl StubOrderService {
    pub fn new(cache: Arc<MarketStatusCache>) -> Self {
        Self { cache, seq: std::sync::atomic::AtomicU64::new(1) }
    }
}

#[async_trait]
impl OrderServiceTrait for StubOrderService {
    async fn submit(&self, _user_id: UserId, req: OrderRequest) -> AppResult<u64> {
        use common::MarketStatus;
        let status = self.cache.get(&req.market_id)
            .ok_or_else(|| AppError::MarketNotFound(req.market_id.0.to_string()))?;
        if status != MarketStatus::Open {
            return Err(AppError::MarketNotOpen(format!("{:?}", status)));
        }
        Ok(self.seq.fetch_add(1, std::sync::atomic::Ordering::Relaxed))
    }
    async fn cancel(&self, _u: UserId, _m: MarketId, _o: OrderId) -> AppResult<()> { Ok(()) }
}

// ── Request / Response types ──────────────────────────────────────────────────

#[derive(Deserialize)]
pub struct SubmitOrderReq {
    pub order_id:   String,
    pub market_id:  String,
    pub side:       String,   // "BUY" or "SELL"
    pub order_type: String,   // "LIMIT" or "MARKET"
    pub price:      Option<f64>,
    pub quantity:   f64,      // in shares
}

#[derive(Serialize)]
pub struct SubmitOrderResp {
    pub order_id:        String,
    pub sequence_number: u64,
    pub status:          &\'static str,
}

// ── Handlers ──────────────────────────────────────────────────────────────────

pub async fn submit_order(
    State(state): State<Arc<AppState>>,
    AuthUser(claims): AuthUser,
    Json(req):    Json<SubmitOrderReq>,
) -> Result<Json<SubmitOrderResp>, (StatusCode, String)> {
    let user_id = claims.user_id()
        .map_err(|e| (StatusCode::UNAUTHORIZED, e.to_string()))?;

    // Parse IDs
    let order_id = Uuid::parse_str(&req.order_id)
        .map(OrderId)
        .unwrap_or_else(|_| OrderId::new());

    let market_id = Uuid::parse_str(&req.market_id)
        .map(MarketId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid market_id".into()))?;

    let side = match req.side.to_uppercase().as_str() {
        "BUY"  => OrderSide::Buy,
        "SELL" => OrderSide::Sell,
        _      => return Err((StatusCode::BAD_REQUEST, "side must be BUY or SELL".into())),
    };

    let order_type = match req.order_type.to_uppercase().as_str() {
        "LIMIT"  => OrderType::Limit,
        "MARKET" => OrderType::Market,
        _        => return Err((StatusCode::BAD_REQUEST, "order_type must be LIMIT or MARKET".into())),
    };

    let price = req.price.and_then(FixedPrice::from_f64);
    let quantity = Quantity::from_shares(req.quantity);

    // Cache-layer deduplication
    if !state.cache.register_order_id(&order_id)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))? {
        return Err((StatusCode::CONFLICT, format!("duplicate order_id: {}", req.order_id)));
    }

    let order_req = OrderRequest { order_id, market_id, side, order_type, price, quantity };

    let seq = state.order_svc.submit(user_id, order_req).await
        .map_err(|e| {
            let code = match &e {
                AppError::MarketNotFound(_) => StatusCode::NOT_FOUND,
                AppError::MarketNotOpen(_)
                | AppError::InsufficientBalance{..}
                | AppError::Validation(_)  => StatusCode::BAD_REQUEST,
                AppError::DuplicateOrder(_)=> StatusCode::CONFLICT,
                AppError::ServiceUnavailable(_) => StatusCode::SERVICE_UNAVAILABLE,
                _                          => StatusCode::INTERNAL_SERVER_ERROR,
            };
            (code, e.to_string())
        })?;

    Ok(Json(SubmitOrderResp {
        order_id: req.order_id,
        sequence_number: seq,
        status: "ACCEPTED",
    }))
}

pub async fn cancel_order(
    State(state):     State<Arc<AppState>>,
    AuthUser(claims): AuthUser,
    Path(order_id):   Path<String>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let user_id = claims.user_id()
        .map_err(|e| (StatusCode::UNAUTHORIZED, e.to_string()))?;

    let oid = Uuid::parse_str(&order_id)
        .map(OrderId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid order_id".into()))?;

    // Look up market_id from DB
    let order = state.db.get_order(&oid)
        .map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))?;

    if order.user_id != user_id {
        return Err((StatusCode::FORBIDDEN, "not your order".into()));
    }

    state.order_svc.cancel(user_id, order.market_id, oid).await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(Json(serde_json::json!({ "status": "CANCEL_SENT", "order_id": order_id })))
}

pub async fn get_order(
    State(state):   State<Arc<AppState>>,
    Path(order_id): Path<String>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let oid = Uuid::parse_str(&order_id)
        .map(OrderId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid order_id".into()))?;
    let order = state.db.get_order(&oid)
        .map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))?;
    Ok(Json(serde_json::json!({ "order": order })))
}
