use axum::{extract::State, Json};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use common::{AppError, UserId};
use crate::state::AppState;

#[derive(Deserialize)]
pub struct TokenRequest {
    /// In production: validate against hashed password in DB.
    /// Here: any non-empty user_id string issues a token.
    pub user_id: String,
}

#[derive(Serialize)]
pub struct TokenResponse {
    pub token:      String,
    pub expires_in: i64,
}

pub async fn issue_token(
    State(state): State<Arc<AppState>>,
    Json(req):    Json<TokenRequest>,
) -> Result<Json<TokenResponse>, (axum::http::StatusCode, String)> {
    let uid = uuid::Uuid::parse_str(&req.user_id)
        .map(common::UserId)
        .unwrap_or_else(|_| UserId::new());

    let token = state.jwt.issue(uid, 0)
        .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(Json(TokenResponse { token, expires_in: 86400 }))
}
