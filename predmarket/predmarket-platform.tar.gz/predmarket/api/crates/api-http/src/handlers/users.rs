use axum::{extract::State, http::StatusCode, Json};
use std::sync::Arc;
use crate::{middleware::AuthUser, state::AppState};

pub async fn my_orders(
    State(state):     State<Arc<AppState>>,
    AuthUser(claims): AuthUser,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let user_id = claims.user_id()
        .map_err(|e| (StatusCode::UNAUTHORIZED, e.to_string()))?;
    let orders = state.db.get_orders_for_user(&user_id);
    Ok(Json(serde_json::json!({ "orders": orders, "count": orders.len() })))
}

pub async fn my_balance(
    State(state):     State<Arc<AppState>>,
    AuthUser(claims): AuthUser,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let user_id = claims.user_id()
        .map_err(|e| (StatusCode::UNAUTHORIZED, e.to_string()))?;
    let bal = state.positions.get_balance(&user_id);
    Ok(Json(serde_json::json!({
        "available": bal.available,
        "reserved":  bal.reserved,
        "total":     bal.total(),
    })))
}
