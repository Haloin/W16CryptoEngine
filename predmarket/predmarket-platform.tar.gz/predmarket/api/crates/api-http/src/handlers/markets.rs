use axum::{extract::{Path, State}, http::StatusCode, Json};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use uuid::Uuid;
use common::{AppError, MarketId, OrderBookDepth};
use crate::state::AppState;

#[derive(Deserialize)]
pub struct CreateMarketReq {
    pub title:       String,
    pub description: String,
}

pub async fn list_markets(
    State(state): State<Arc<AppState>>,
) -> Json<serde_json::Value> {
    let markets = state.markets.list();
    Json(serde_json::json!({ "markets": markets, "count": markets.len() }))
}

pub async fn create_market(
    State(state): State<Arc<AppState>>,
    Json(req):    Json<CreateMarketReq>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let market = state.markets.create(req.title, req.description)
        .map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?;
    Ok(Json(serde_json::json!({ "market": market })))
}

pub async fn get_market(
    State(state): State<Arc<AppState>>,
    Path(id):     Path<String>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let mid = Uuid::parse_str(&id)
        .map(MarketId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid market_id".into()))?;
    let market = state.markets.get(&mid)
        .map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))?;
    Ok(Json(serde_json::json!({ "market": market })))
}

pub async fn get_depth(
    State(state): State<Arc<AppState>>,
    Path(id):     Path<String>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let mid = Uuid::parse_str(&id)
        .map(MarketId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid market_id".into()))?;
    // In production: read from Redis depth cache
    // Here: return empty depth (C++ engine would populate this)
    let depth = OrderBookDepth { market_id: mid, bids: vec![], asks: vec![], sequence: 0 };
    Ok(Json(serde_json::json!({ "depth": depth })))
}

pub async fn get_trades(
    State(state): State<Arc<AppState>>,
    Path(id):     Path<String>,
) -> Result<Json<serde_json::Value>, (StatusCode, String)> {
    let mid = Uuid::parse_str(&id)
        .map(MarketId)
        .map_err(|_| (StatusCode::BAD_REQUEST, "invalid market_id".into()))?;
    let fills = state.db.get_fills_for_market(&mid);
    Ok(Json(serde_json::json!({ "trades": fills, "count": fills.len() })))
}
