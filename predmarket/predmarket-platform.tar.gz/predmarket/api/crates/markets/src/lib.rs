// crates/markets/src/lib.rs
use common::{AppError, AppResult, Market, MarketId, MarketStatus};
use orders::MarketStatusCache;
use std::{collections::HashMap, sync::{Arc, RwLock}};
use chrono::Utc;
use tracing::info;

pub struct MarketService {
    store:        Arc<RwLock<HashMap<MarketId, Market>>>,
    status_cache: Arc<MarketStatusCache>,
}

impl MarketService {
    pub fn new(status_cache: Arc<MarketStatusCache>) -> Self {
        Self {
            store:        Arc::new(RwLock::new(HashMap::new())),
            status_cache,
        }
    }

    pub fn create(&self, title: String, description: String) -> AppResult<Market> {
        let market = Market {
            market_id:   MarketId::new(),
            title,
            description,
            status:      MarketStatus::Open,
            created_at:  Utc::now(),
            resolves_at: None,
        };
        self.status_cache.set(market.market_id, MarketStatus::Open);
        self.store.write().unwrap().insert(market.market_id, market.clone());
        info!(market_id = %market.market_id.0, "market created");
        Ok(market)
    }

    pub fn get(&self, id: &MarketId) -> AppResult<Market> {
        self.store.read().unwrap()
            .get(id)
            .cloned()
            .ok_or_else(|| AppError::MarketNotFound(id.0.to_string()))
    }

    pub fn list(&self) -> Vec<Market> {
        self.store.read().unwrap().values().cloned().collect()
    }

    pub fn set_status(&self, id: &MarketId, status: MarketStatus) -> AppResult<()> {
        let mut store = self.store.write().unwrap();
        let market = store.get_mut(id)
            .ok_or_else(|| AppError::MarketNotFound(id.0.to_string()))?;
        market.status = status;
        self.status_cache.set(*id, status);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    fn svc() -> MarketService {
        MarketService::new(Arc::new(MarketStatusCache::new()))
    }

    #[test]
    fn create_and_get() {
        let svc = svc();
        let m = svc.create("Will BTC hit 100k?".into(), "Resolves YES if...".into()).unwrap();
        assert_eq!(m.status, MarketStatus::Open);
        let got = svc.get(&m.market_id).unwrap();
        assert_eq!(got.title, m.title);
    }

    #[test]
    fn status_change_propagates_to_cache() {
        let cache = Arc::new(MarketStatusCache::new());
        let svc = MarketService::new(cache.clone());
        let m = svc.create("Test market".into(), "desc".into()).unwrap();
        svc.set_status(&m.market_id, MarketStatus::Settled).unwrap();
        assert_eq!(cache.get(&m.market_id), Some(MarketStatus::Settled));
    }

    #[test]
    fn list_returns_all() {
        let svc = svc();
        svc.create("M1".into(), "d".into()).unwrap();
        svc.create("M2".into(), "d".into()).unwrap();
        assert_eq!(svc.list().len(), 2);
    }
}
